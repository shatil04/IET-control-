"""Continuous-frequency certificate (Theorem B3) for model v2 (dirb39v2).

Certificate at w with multipliers M = blkdiag(m_owner(j)) (Theorem 1):
    P0(w) = Her(M (Br (x) F(jw) + blkdiag Y_pas,j)) > 0   and   H(w) = Her(M (Br (x) F(jw) + blkdiag Y_j(jw))) > 0,
    Y_pas = capacitors + conductance + RC damping (the passive reference system of the homotopy).
M is piecewise constant in w. Bands:
  [0, w_s] : sampled SDP multipliers; on every interval [c-h, c+h] a rigorous lower bound (below);
             adaptive bisection where it is inconclusive.
  [w_s, w_T]: M = I. Then P0 >= Br (x) Her F > 0 analytically and H >= blkdiag Her Y_j, so it suffices that every
             bus has Her Y_j(jw) > 0 (2x2, decentralised); intervals as below.
  [w_T, inf): M = I, monotone analytic bound per bus (tail_ok).

Interval lower bound on [c-h, c+h] (all norms spectral). Write m0 = common multiplier, E = M - I(x)m0 (non-zero only
on rows with an own multiplier), Y_j = C_j (jwI + w0 J) + Y_j^r (capacitive part exact, Y^r = conductance + GFL + RC).
  ||F'|| <= dF := (1/w0)||F(c)||^2/(1 - h||F(c)||/w0)^2
  G0 = Her(m0 F):  G0(w) >= kappa G0(c),  kappa = 1 - ||m0|| h dF ||G0(c)^-1||      (needs G0(c) > 0, kappa > 0)
     and since Br > 0:  Br (x) G0(w) >= kappa Br (x) G0(c)
  ||Her(E (Br (x) (F(w)-F(c))))|| <= eE := max_j ||m_j - m0|| * ||Br[own rows, :]|| * h * dF
  Her(m_j C_j (jw I + w0 J)) = C_j (w Her(j m_j) + w0 Her(m_j J))  -> deviation <= C_j h ||Her(j m_j)||
  ||Y_j^r'|| <= GFL: ||C R(c)|| ||R(c) B|| / (1 - h||R(c)||)^2  +  RC: cf ||K(c)||^2 / (1 - h rc ||K(c)||)^2
Hence  lambda_min H(w) >= lambda_min( kappa N0(c) + NE(c) + D(c) ) - eE - h max_j (C_j||Her(j m_j)|| + ||m_j|| dY_j^r)
and    lambda_min N(w) >= lambda_min( kappa N0(c) + NE(c) ) - eE."""
import numpy as np, scipy.linalg as sla
from testbed9 import J, I2, w0
import dirb39v2 as M2
from dirb39 import Finv

def realH(X):
    H = 0.5 * (X + X.conj().T); return np.block([[H.real, -H.imag], [H.imag, H.real]])
def lmin(X): return float(np.linalg.eigvalsh(X)[0])
def her(X): return 0.5 * (X + X.conj().T)

_bal = {}
def balanced(s, b):
    key = (id(s), b)
    if key not in _bal:
        A, Bd, C, D = s.devs[b]; _, T = sla.matrix_balance(A, permute=False, separate=False)
        Ti = np.linalg.inv(T); _bal[key] = (Ti @ A @ T, Ti @ Bd, C @ T, D)
    return _bal[key]

def dparts(s, b, c, h):
    """bounds on ||Y_gfl'|| and ||Y_RC'|| over [c-h, c+h] at bus b (0 if absent; inf if a Neumann condition fails)"""
    if b not in s.devs: return 0.0, 0.0
    sl = 1j * c; A, Bd, C, D = balanced(s, b); R = np.linalg.inv(sl * np.eye(len(A)) - A); nR = np.linalg.norm(R, 2)
    dg = np.inf if h * nR >= 1 else np.linalg.norm(C @ R, 2) * np.linalg.norm(R @ Bd, 2) / (1 - h * nR) ** 2
    rc = s.rd[b] * s.cf[b]; K = np.linalg.inv(I2 + rc * (sl * I2 + w0 * J)); nK = np.linalg.norm(K, 2)
    dr = np.inf if h * rc * nK >= 1 else s.cf[b] * nK ** 2 / (1 - h * rc * nK) ** 2
    return dg, dr

def dYr(s, b, c, h):
    dg, dr = dparts(s, b, c, h); return dg + dr

def bound(s, c, h, ms, owner):
    """rigorous lower bounds (lbP0, lbH) on [c-h, c+h]; P0 = Her(M(Y_net + Y_pas)) (Theorem 1 endpoint)"""
    Br = s.Br; n = Br.shape[0]; sl = 1j * c; Fc = np.linalg.inv(Finv(sl)); nF = np.linalg.norm(Fc, 2)
    q = h * nF / w0
    if q >= 1: return -np.inf, -np.inf
    dF = (nF ** 2 / w0) / (1 - q) ** 2
    m0 = ms[0]; G0 = her(m0 @ Fc); eg = np.linalg.eigvalsh(G0)
    if eg[0] <= 0: return -np.inf, -np.inf
    kappa = 1 - np.linalg.norm(m0, 2) * h * dF / eg[0]
    if kappa <= 0: return -np.inf, -np.inf
    own = [j for j in range(n) if owner[j] != 0]
    N0 = realH(np.kron(Br, m0 @ Fc))
    if own:
        Mb = np.zeros((2 * n, 2 * n), complex)
        for j in own: Mb[2*j:2*j+2, 2*j:2*j+2] = ms[owner[j]] - m0
        NE = realH(Mb @ np.kron(Br, Fc))
        eE = max(np.linalg.norm(ms[owner[j]] - m0, 2) for j in own) * np.linalg.norm(Br[own, :], 2) * h * dF
    else:
        NE = 0.0; eE = 0.0
    Dc = np.zeros((2 * n, 2 * n), complex); Dp = np.zeros_like(Dc); dev = 0.0; devp = 0.0
    for j, b in enumerate(s.keep):
        m = ms[owner[j]]; Dc[2*j:2*j+2, 2*j:2*j+2] = m @ M2.Ydev(s, b, sl); Dp[2*j:2*j+2, 2*j:2*j+2] = m @ M2.Ypas(s, b, sl)
        dg, dr = dparts(s, b, c, h); cap = s.C[b] * np.linalg.norm(her(1j * m), 2); nm = np.linalg.norm(m, 2)
        dev = max(dev, cap + nm * (dg + dr)); devp = max(devp, cap + nm * dr)
    Nlow = kappa * N0 + NE
    return lmin(Nlow + realH(Dp)) - eE - h * devp, lmin(Nlow + realH(Dc)) - eE - h * dev

def interval(s, a, b, ms, owner, stats, depth=0, maxdepth=30):
    c = 0.5 * (a + b); h = 0.5 * (b - a); stats["evals"] += 1
    lbN, lbH = bound(s, c, h, ms, owner)
    if lbN > 0 and lbH > 0: return True
    if h == 0 or depth >= maxdepth: return False
    if h < 1e-9 * max(c, 1.0): return False
    return interval(s, a, c, ms, owner, stats, depth + 1, maxdepth) and interval(s, c, b, ms, owner, stats, depth + 1, maxdepth)

# ---------- identity-multiplier band: per-bus 2x2 checks ----------
def bus_interval(s, b, a, bb, stats, depth=0, maxdepth=40):
    c = 0.5 * (a + bb); h = 0.5 * (bb - a); stats["evals"] += 1
    Yr = M2.Ydev(s, b, 1j * c) - s.C[b] * (1j * c * I2 + w0 * J)      # capacitor drops out of Her exactly
    lb = np.linalg.eigvalsh(her(Yr))[0] - h * dYr(s, b, c, h)
    if lb > 0: return True
    if depth >= maxdepth: return False
    return bus_interval(s, b, a, c, stats, depth + 1, maxdepth) and bus_interval(s, b, c, bb, stats, depth + 1, maxdepth)

def identity_band(s, ws_, wT, stats):
    """True if Her Y_j > 0 on [ws_, wT] for every kept bus (M = I)"""
    bad = []
    for b in s.keep:
        if b not in s.devs:
            if s.g[b] <= 0: bad.append(b)
            continue
        grid = np.geomspace(ws_, wT, 200)
        for a, bb in zip(grid[:-1], grid[1:]):
            if not bus_interval(s, b, a, bb, stats): bad.append((b, a / 2 / np.pi, bb / 2 / np.pi)); break
    return bad

def tail_ok(s, wT):
    """M = I on [wT, inf): min over buses of a monotone lower bound on lambda_min Her Y_j(jw)"""
    worst = np.inf
    for b in s.keep:
        lb = s.g[b]
        if b in s.devs:
            A, Bd, C, D = balanced(s, b); nA = np.linalg.norm(A, 2)
            if wT <= nA + w0: return -np.inf
            CB = C @ Bd; sk = np.linalg.norm(0.5 * (CB - CB.T), 2)
            rc = s.rd[b] * s.cf[b]; nK = 1 / np.sqrt(1 + (rc * (wT - w0)) ** 2)
            lb += (1 / s.rd[b]) * (1 - nK) - sk / wT - np.linalg.norm(C @ A, 2) * np.linalg.norm(Bd, 2) / (wT * (wT - nA)) \
                  - np.linalg.norm(D, 2)
        worst = min(worst, lb)
    return worst

def certify_continuous(s, recs, w_id, wT, log=print):
    """recs: list of (w, margin, ms, owner, mode) at increasing sample frequencies (first should be ~0);
    band [0, recs[0].w] uses recs[0]'s multipliers; band [w_id, wT] uses M = I (w_id must be a sample frequency)."""
    stats = {"evals": 0}; bad = []
    pts = [0.0] + [r[0] for r in recs if r[0] <= w_id]; mult = [recs[0]] + [r for r in recs if r[0] <= w_id]
    for i in range(len(pts) - 1):
        ok = False
        for r in (mult[i], mult[i + 1]):
            if r[1] > 0 and interval(s, pts[i], pts[i + 1], r[2], r[3], stats): ok = True; break
        if not ok: bad.append((round(pts[i] / 2 / np.pi, 3), round(pts[i + 1] / 2 / np.pi, 3)))
    idb = identity_band(s, w_id, wT, stats); t = tail_ok(s, wT)
    res = dict(low_band_failed=bad, identity_band_failed=idb, tail_margin=t, evals=stats["evals"],
               certified=(not bad and not idb and t > 0))
    log(res); return res

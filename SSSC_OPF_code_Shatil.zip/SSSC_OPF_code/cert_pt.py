import os, sys, json, numpy as np, acopf as A, dirb39v2 as M2, bf_cert as BF
h = json.load(open(sys.argv[1])); x = np.array(h[-1]['x']); Pg, kw = A.bk(x); net = A.pf(x)
r = BF.cert_spectral(Pg, **kw); ev = M2.eig(r["s"])
print(sys.argv[1], "load", os.environ.get("LOAD_SCALE"), "cost", round(A.cost(x, net)), "GFL", round(sum(Pg.values())), "viol", round(A.viol(A.gvec(net)), 5),
      "maxRe", round(ev.real.max(), 2), "| spectral certificate", r["certified"], r.get("reason", ""), f"{r['time']:.0f}s", flush=True)

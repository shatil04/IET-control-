"""Rigorous continuous-frequency certificate for model v2 at a dispatch P.
1. sample multipliers on WS (common scalar SDP; hybrid by first-order ascent), exact full-block verification
2. intervals between samples (dirb_cont.interval); failing intervals get extra samples (midpoint multipliers)
3. identity band [w_id, w_T] per bus, analytic tail above w_T."""
import numpy as np, time, json, sys, pickle
import dirb39v2 as M2, fast_sdp as FS, dirb_cont as K, bf_cert as BF
from dirb39 import Finv, WS
from dirb39_probe2 import P0, GFL

WT = 2.2e5

def sample(s, w, warm=None):
    special = [s.keep.index(b) for b in s.gfl]
    F = np.linalg.inv(Finv(1j * w)); Ys = [M2.Ydev(s, b, 1j * w) for b in s.keep]
    Yp = [M2.Ypas(s, b, 1j * w) for b in s.keep]
    v, mo, mode = FS.step_block(F, Ys, s.Br, special, warm=warm, Ypas=Yp)
    return (w, v, mo[0], mo[1], mode)

def certify(P, log=print, max_extra=12, f_split=300.0, use_bf=True, **bk):
    """Tiered continuous certificate on [0, inf):
    structured multipliers (common / hybrid; decentralised) wherever they certify an interval, and the exact
    spectral homotopy test with Bauer-Fike bounds (centralised) on the intervals where they do not."""
    t0 = time.time(); s = M2.build(P, GFL, **bk)
    ws_low = [w for w in WS if w <= 2 * np.pi * f_split * 1.0001]
    recs = []
    for w in ws_low:
        warm = recs[-1][2] if recs and recs[-1][2] is not None and recs[-1][1] > 0 else None
        r = sample(s, w, warm)
        if not r[1] > 0: r = (w, -np.inf, None, None, "none")
        recs.append(r)
    nfail = sum(1 for r in recs if not r[1] > 0)
    log(f"  samples: {len(recs)} ({sum(r[4]=='hybrid' for r in recs)} hybrid, {nfail} without structured multiplier) [{time.time()-t0:.0f}s]")
    stats = {"evals": 0}; bfst = {"evals": 0}; extra = 0; pts = [(0.0, recs[0])] + [(r[0], r) for r in recs]
    i = 0; bf_cells = []
    while i < len(pts) - 1:
        (a, ra), (b, rb) = pts[i], pts[i + 1]
        ok = any(r[1] > 0 and K.interval(s, a, b, r[2], r[3], stats, maxdepth=16) for r in (ra, rb))
        if ok: i += 1; continue
        if (ra[1] > 0 or rb[1] > 0) and extra < max_extra:
            c = 0.5 * (a + b); src = ra if ra[1] > 0 else rb; rc = sample(s, c, src[2]); extra += 1
            if rc[1] > 0: pts.insert(i + 1, (c, rc)); continue
        if not use_bf:
            return dict(certified=False, reason=f"interval [{a/2/np.pi:.3f},{b/2/np.pi:.3f}] Hz", time=time.time() - t0, s=s)
        okb, where = BF.bf_interval(s, a, b, bfst, maxdepth=24)
        if not okb:
            return dict(certified=False, reason=f"spectral test fails near {where/2/np.pi:.3f} Hz", time=time.time() - t0, s=s)
        bf_cells.append((a / 2 / np.pi, b / 2 / np.pi)); i += 1
    log(f"  low band [0, {f_split:.0f} Hz] certified: {len(pts)} points ({extra} extra), {stats['evals']} structured evals, "
        f"{len(bf_cells)} intervals by spectral test ({bfst['evals']} evals) [{time.time()-t0:.0f}s]")
    idb = K.identity_band(s, pts[-1][0], WT, stats); tail = K.tail_ok(s, WT)
    if idb or not tail > 0:
        return dict(certified=False, reason=f"identity band {idb[:2]} / tail {tail}", time=time.time() - t0, s=s)
    good = [r for _, r in pts if r[1] > 0]
    marginH = min(FS.verify_H(s, r) for r in good) if good else 0.0
    log(f"  identity band and tail ok (tail {tail:.2e}); min structured margin H {marginH:.4f} [{time.time()-t0:.0f}s]")
    return dict(certified=True, margin=marginH, points=len(pts), extra=extra, evals=stats["evals"], bf_cells=bf_cells,
                bf_evals=bfst["evals"], tail=tail, time=time.time() - t0, recs=good, s=s)

if __name__ == "__main__":
    out = {}
    for x in [float(a) for a in sys.argv[1:]]:
        P = {b: x * P0[b] for b in GFL}; print(f"x = {x}", flush=True)
        r = certify(P, log=lambda m: print(m, flush=True))
        st = bool(M2.eig(r["s"]).real.max() < 0)
        if r.get("recs"): pickle.dump(r["recs"], open(f"recs_v2_{int(round(x*100))}.pkl", "wb"))
        print(f"x = {x}: CONTINUOUS CERTIFICATE {r['certified']}  | truth stable {st}  | {r.get('reason','')} [{r['time']/60:.1f} min]", flush=True)
        out[x] = dict(certified=r["certified"], stable=st, margin=r.get("margin"), reason=r.get("reason"), minutes=r["time"] / 60,
                      points=r.get("points"), extra=r.get("extra"), evals=r.get("evals"), bf_cells=r.get("bf_cells"), bf_evals=r.get("bf_evals"))
        json.dump(out, open("cert_tiered_scan.json", "w"), indent=1, default=float)

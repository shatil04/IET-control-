"""Multiplier SDP written directly in Clarabel conic form (no CVXPY): memory-light and fast.
Variables x = [a (G x 4), b (G x 4), nu (n), t];  m_g = sum_q (a_gq + j b_gq) E_q.
maximise t  s.t.
   Her(m_owner(j) Y_j) - nu_j I  >= 0        (4x4 real embeddings, one per bus)
   N(m) - g_min I >= 0,   N(m) + blkdiag(nu_j I) - t I >= 0   (4n x 4n real embeddings)
   ||(a_g, b_g)|| <= 1                        (normalisation, one SOC per multiplier group)
Clarabel: A x + s = b, s in K; PSD cone in svec (upper triangle, column-major, off-diagonals * sqrt 2)."""
import numpy as np, scipy.sparse as sp, clarabel

E = [np.array([[1, 0], [0, 0]], complex), np.array([[0, 1], [0, 0]], complex),
     np.array([[0, 0], [1, 0]], complex), np.array([[0, 0], [0, 1]], complex)]

def realH(X):
    H = 0.5 * (X + X.conj().T); return np.block([[H.real, -H.imag], [H.imag, H.real]])

def _svec_idx(k):
    r, c = np.triu_indices(k); order = np.lexsort((r, c))      # column-major upper triangle
    r, c = r[order], c[order]; scale = np.where(r == c, 1.0, np.sqrt(2.0)); return r, c, scale

_cache = {}
def svec(S):
    k = S.shape[0]
    if k not in _cache: _cache[k] = _svec_idx(k)
    r, c, sc = _cache[k]; return S[r, c] * sc

def smat(v, k):
    r, c, sc = _cache[k]; S = np.zeros((k, k)); S[r, c] = v / sc; S[c, r] = v / sc; return S

def solve_common(F, Ys, Br, g_min=1e-6, verbose=False, Ypas=None):
    """Scalar form (common m): Her(mF) >= g I; Her(m Y_j) >= nu_j I; g Br + diag(nu) - t I >= 0; and, for the passive
    endpoint (Theorem 1), Her(m Ypas_j) >= mu_j I, g Br + diag(mu) - t I >= 0.  ||m|| <= 1, g >= g_min.
    Variables x = [a(4), b(4), g, nu(n), mu(n if Ypas), t]."""
    n = len(Ys); npas = n if Ypas is not None else 0
    nv = 8 + 1 + n + npas + 1; ig = 8; inu = lambda j: 9 + j; imu = lambda j: 9 + n + j; it = 9 + n + npas
    rows_A, rows_b, cones = [], [], []
    def small(Mat, iscal):
        A = np.zeros((10, nv))
        for q in range(4): A[:, q] = -svec(realH(E[q] @ Mat)); A[:, 4 + q] = -svec(realH(1j * E[q] @ Mat))
        A[:, iscal] = svec(np.eye(4)); return sp.csc_matrix(A)
    rows_A.append(small(F, ig)); rows_b.append(np.zeros(10)); cones.append(clarabel.PSDTriangleConeT(4))
    for j, Y in enumerate(Ys):
        rows_A.append(small(Y, inu(j))); rows_b.append(np.zeros(10)); cones.append(clarabel.PSDTriangleConeT(4))
    if npas:
        for j, Y in enumerate(Ypas):
            rows_A.append(small(Y, imu(j))); rows_b.append(np.zeros(10)); cones.append(clarabel.PSDTriangleConeT(4))
    L = n * (n + 1) // 2
    for idx in ([inu] + ([imu] if npas else [])):
        A = np.zeros((L, nv)); A[:, ig] = -svec(Br)
        for j in range(n):
            d = np.zeros(n); d[j] = 1; A[:, idx(j)] = -svec(np.diag(d))
        A[:, it] = svec(np.eye(n)); rows_A.append(sp.csc_matrix(A)); rows_b.append(np.zeros(L)); cones.append(clarabel.PSDTriangleConeT(n))
    A = np.zeros((1, nv)); A[0, ig] = -1; rows_A.append(sp.csc_matrix(A)); rows_b.append(np.array([-g_min])); cones.append(clarabel.NonnegativeConeT(1))
    A = np.zeros((9, nv)); bb = np.zeros(9); bb[0] = 1
    for q in range(8): A[1 + q, q] = -1
    rows_A.append(sp.csc_matrix(A)); rows_b.append(bb); cones.append(clarabel.SecondOrderConeT(9))
    A = sp.vstack(rows_A).tocsc(); b = np.concatenate(rows_b); qv = np.zeros(nv); qv[it] = -1
    st = clarabel.DefaultSettings(); st.verbose = verbose; st.max_iter = 200; st.chordal_decomposition_enable = False
    sol = clarabel.DefaultSolver(sp.csc_matrix((nv, nv)), qv, A, b, cones, st).solve()
    if str(sol.status) not in ("Solved", "AlmostSolved", "InsufficientProgress", "MaxIterations", "AlmostInsufficientProgress") or sol.x is None or not np.all(np.isfinite(sol.x)): return -np.inf, None
    x = np.array(sol.x); return float(x[it]), [sum((x[q] + 1j * x[4 + q]) * E[q] for q in range(4))]

def solve(F, Ys, Br, owner, G, g_min=1e-6, verbose=False, ncone=False):
    """owner: dict bus j -> group index in 0..G-1. Returns (t, ms) with ms list of G complex 2x2."""
    n = len(Ys); nv = 8 * G + n + 1
    ia = lambda g, q: 8 * g + q; ib = lambda g, q: 8 * g + 4 + q; inu = lambda j: 8 * G + j; it = 8 * G + n
    rows_A, rows_b, cones = [], [], []
    # per-bus 4x4
    for j, Y in enumerate(Ys):
        g = owner[j]; cols = {}
        for q in range(4):
            cols[ia(g, q)] = realH(E[q] @ Y); cols[ib(g, q)] = realH(1j * E[q] @ Y)
        cols[inu(j)] = -np.eye(4)
        A = np.zeros((10, nv))
        for i, Mi in cols.items(): A[:, i] = -svec(Mi)
        rows_A.append(sp.csc_matrix(A)); rows_b.append(np.zeros(10)); cones.append(clarabel.PSDTriangleConeT(4))
    # network coefficient matrices (4n x 4n), one per (group, q, re/im)
    k = 4 * n; L = k * (k + 1) // 2; netcols = {}
    for g in range(G):
        rows = [j for j in range(n) if owner[j] == g]
        if not rows: continue
        R = np.zeros((n, n)); R[rows, :] = Br[rows, :]
        for q in range(4):
            K = np.kron(R, E[q] @ F); netcols[ia(g, q)] = svec(realH(K)); netcols[ib(g, q)] = svec(realH(1j * K))
    def big(with_nu_t, const):
        A = np.zeros((L, nv))
        for i, v in netcols.items(): A[:, i] = -v
        if with_nu_t:
            for j in range(n):
                d = np.zeros(k); d[[2*j, 2*j+1, 2*n+2*j, 2*n+2*j+1]] = 1.0; A[:, inu(j)] = -svec(np.diag(d))
            A[:, it] = svec(np.eye(k))
        return sp.csc_matrix(A), -svec(const * np.eye(k))
    A2, b2 = big(True, 0.0); rows_A += [A2]; rows_b += [b2]; cones += [clarabel.PSDTriangleConeT(k)]
    if ncone:
        A1, b1 = big(False, g_min); rows_A += [A1]; rows_b += [b1]; cones += [clarabel.PSDTriangleConeT(k)]
    for g in range(G):                                            # SOC: (1, a_g, b_g)
        A = np.zeros((9, nv)); bb = np.zeros(9); bb[0] = 1.0
        for q in range(4): A[1 + q, ia(g, q)] = -1.0; A[5 + q, ib(g, q)] = -1.0
        rows_A.append(sp.csc_matrix(A)); rows_b.append(bb); cones.append(clarabel.SecondOrderConeT(9))
    A = sp.vstack(rows_A).tocsc(); b = np.concatenate(rows_b)
    P = sp.csc_matrix((nv, nv)); qv = np.zeros(nv); qv[it] = -1.0
    st = clarabel.DefaultSettings(); st.verbose = verbose; st.max_iter = 200; st.chordal_decomposition_enable = False
    sol = clarabel.DefaultSolver(P, qv, A, b, cones, st).solve()
    if str(sol.status) not in ("Solved", "AlmostSolved", "InsufficientProgress", "MaxIterations", "AlmostInsufficientProgress") or sol.x is None or not np.all(np.isfinite(sol.x)): print("clarabel status", sol.status); return -np.inf, None
    x = np.array(sol.x)
    ms = [sum((x[ia(g, q)] + 1j * x[ib(g, q)]) * E[q] for q in range(4)) for g in range(G)]
    return float(x[it]), ms

def step(F, Ys, Br, special, verify):
    """common multiplier, then hybrid; each verified exactly by `verify(F, Ys, Br, ms, owner)`."""
    n = len(Ys); sc = 1.0 / np.abs(Br).max(); Yss = [Y * sc for Y in Ys]; Brs = Br * sc
    own0 = {j: 0 for j in range(n)}
    t, ms = solve_common(F, Yss, Brs)
    if ms is not None:
        v = verify(F, Ys, Br, ms, own0)
        if v > 0: return v, (ms, own0), "common"
    ownh = {j: (1 + special.index(j) if j in special else 0) for j in range(n)}
    for nc in (False, True):
        t, ms = solve(F, Yss, Brs, ownh, 1 + len(special), ncone=nc)
        if ms is None: continue
        v = verify(F, Ys, Br, ms, ownh)
        if v > 0: return v, (ms, ownh), "hybrid"
        if t <= 0: break
    return -np.inf, None, "none"

# ---------------- full-block certificate and first-order hybrid multiplier search ----------------
from scipy.optimize import minimize

def blocks(F, Ys, Br, ms, owner, Ypas=None):
    """real embeddings of the endpoint matrix and H = Her(M(Y_net + Y_dev)).
    Endpoint: P0 = Her(M(Y_net + Y_pas)) if Ypas is given (Theorem 1), else N = Her(M Y_net)."""
    n = len(Ys); Mb = np.zeros((2 * n, 2 * n), complex); Yd = np.zeros((2 * n, 2 * n), complex); Yp = np.zeros_like(Yd)
    for j in range(n):
        Mb[2*j:2*j+2, 2*j:2*j+2] = ms[owner[j]]; Yd[2*j:2*j+2, 2*j:2*j+2] = Ys[j]
        if Ypas is not None: Yp[2*j:2*j+2, 2*j:2*j+2] = Ypas[j]
    Yn = np.kron(Br, F); return realH(Mb @ (Yn + Yp)), realH(Mb @ (Yn + Yd))

def verify_block(F, Ys, Br, ms, owner, Ypas=None):
    P, H = blocks(F, Ys, Br, ms, owner, Ypas)
    return min(np.linalg.eigvalsh(P)[0], np.linalg.eigvalsh(H)[0])

def hybrid_ascent(F, Ys, Br, owner, G, m_init, iters=(0.3, 0.1, 0.03, 0.01, 0.003), Ypas=None):
    """maximise min(lmin N(m), lmin H(m)) over per-group multipliers, ||m_g||_F <= 1 (concave in m)."""
    n = len(Ys); CN, CH = [], []
    for g in range(G):
        rows = [j for j in range(n) if owner[j] == g]; R = np.zeros((n, n)); R[rows, :] = Br[rows, :]
        for part in (1.0, 1j):
            for q in range(4):
                Kn = np.kron(R, part * E[q] @ F); Kd = np.zeros((2 * n, 2 * n), complex); Kp = np.zeros_like(Kd)
                for j in rows:
                    Kd[2*j:2*j+2, 2*j:2*j+2] = part * E[q] @ Ys[j]
                    if Ypas is not None: Kp[2*j:2*j+2, 2*j:2*j+2] = part * E[q] @ Ypas[j]
                CN.append(realH(Kn + Kp)); CH.append(realH(Kn + Kd))
    CN = np.array(CN); CH = np.array(CH); nv = 8 * G
    # variable order: g, (re q0..3, im q0..3)
    def unpack(x): return [sum((x[8*g+q] + 1j * x[8*g+4+q]) * E[q] for q in range(4)) for g in range(G)]
    def pack(ms):
        x = np.zeros(nv)
        for g, m in enumerate(ms):
            for q, (r, c) in enumerate([(0, 0), (0, 1), (1, 0), (1, 1)]): x[8*g+q] = m[r, c].real; x[8*g+4+q] = m[r, c].imag
        return x
    def fval(x, mu, grad=True):
        N = np.tensordot(x, CN, 1); H = np.tensordot(x, CH, 1)
        lN, VN = np.linalg.eigh(N); lH, VH = np.linalg.eigh(H)
        lam = np.concatenate([lN, lH]); l0 = lam.min(); w = np.exp(-(lam - l0) / mu); Z = w.sum()
        f = l0 - mu * np.log(Z)
        if not grad: return f
        wN = w[:len(lN)] / Z; wH = w[len(lN):] / Z
        g = np.einsum('kij,ia,ja,a->k', CN, VN, VN, wN, optimize=True) + np.einsum('kij,ia,ja,a->k', CH, VH, VH, wH, optimize=True)
        return f, g
    x = pack([m_init] * G) if not isinstance(m_init, list) else pack(m_init)
    cons = [{'type': 'ineq', 'fun': (lambda x, g=g: 1 - x[8*g:8*g+8] @ x[8*g:8*g+8]),
             'jac': (lambda x, g=g: np.concatenate([np.zeros(8*g), -2 * x[8*g:8*g+8], np.zeros(8*(G-g-1))]))} for g in range(G)]
    def exact(x):
        return min(np.linalg.eigvalsh(np.tensordot(x, CN, 1))[0], np.linalg.eigvalsh(np.tensordot(x, CH, 1))[0])
    best_x, best = x.copy(), exact(x)
    for rel in iters:
        H0 = np.tensordot(x, CH, 1); ev = np.linalg.eigvalsh(H0); scale = max(abs(exact(x)), 1e-3 * (ev[-1] - ev[0]))
        mu = rel * scale; fs = 1.0 / scale
        r = minimize(lambda x: tuple(-v * fs for v in fval(x, mu)), x, jac=True, method='SLSQP', constraints=cons,
                     options={'maxiter': 400, 'ftol': 1e-12})
        x = r.x; e = exact(x)
        if e > best: best, best_x = e, x.copy()
        else: x = best_x.copy()
    return unpack(best_x)

TOL = 1e-3      # minimum normalised margin (multipliers scaled to max spectral norm 1)
IMPROVE = 0.05  # below this common margin, also try the hybrid multiplier and keep the better

def step_block(F, Ys, Br, special, warm=None, Ypas=None):
    """common (scalar SDP) first; if its full-block value fails, hybrid by first-order ascent. Exact block verification."""
    n = len(Ys); sc = 1.0 / np.abs(Br).max(); Yss = [Y * sc for Y in Ys]; Brs = Br * sc
    own0 = {j: 0 for j in range(n)}
    t, ms = solve_common(F, Yss, Brs, Ypas=[Y * sc for Y in Ypas] if Ypas is not None else None)
    if ms is not None:
        v = verify_block(F, Ys, Br, ms, own0, Ypas) / max(np.linalg.norm(ms[0], 2), 1e-300)
        if v > IMPROVE: return v, ([m / np.linalg.norm(m, 2) for m in ms], own0), "common"
        common = (v, ([m / np.linalg.norm(m, 2) for m in ms], own0), "common") if v > TOL else None
    else: common = None
    ownh = {j: (1 + special.index(j) if j in special else 0) for j in range(n)}
    starts = []
    if warm is not None: starts.append(list(warm) if len(warm) == 1 + len(special) else [warm[0]] * (1 + len(special)))
    if ms is not None and np.linalg.norm(ms[0]) > 0: starts.append(ms[0] / np.linalg.norm(ms[0], 2))
    starts.append(np.eye(2, dtype=complex) / np.sqrt(2))
    best = (-np.inf, None)
    for st in starts:
        mh = hybrid_ascent(F, Ys, Br, ownh, 1 + len(special), st, Ypas=Ypas); nm = max(np.linalg.norm(m, 2) for m in mh)
        mh = [m / nm for m in mh]; v = verify_block(F, Ys, Br, mh, ownh, Ypas)
        if v > best[0]: best = (v, mh)
        if v > max(TOL, common[0] if common else 0) * 1.5: break
    if common and common[0] >= best[0]: return common
    return (best[0], (best[1], ownh), "hybrid" if best[0] > TOL else "none")

def verify_H(s, r):
    """lambda_min H at sample record r = (w, v, ms, owner, mode) for system s (model v2)"""
    import dirb39v2 as M2
    from dirb39 import Finv
    w = r[0]; F = np.linalg.inv(Finv(1j * w)); Ys = [M2.Ydev(s, b, 1j * w) for b in s.keep]
    return float(np.linalg.eigvalsh(blocks(F, Ys, s.Br, r[2], r[3])[1])[0])

def her(X): return 0.5 * (X + X.conj().T)

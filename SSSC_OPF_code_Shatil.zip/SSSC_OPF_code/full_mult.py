"""Full (centralised) multiplier tier for Theorem 1/2.
At c: Z = Y0^-1 Y1 = T Lam T^-1; M = T^-H diag(exp(-j arg(lam)/2)) T^-1 Y0^-1, normalised ||M|| = 1.
Her(M Y0) > 0 and Her(M Y1) > 0 iff no eigenvalue of Z on (-inf, 0] (exact homotopy condition at c).
Interval [c-h, c+h] with M fixed: lambda_min Her(M Y(w)) >= lambda_min Her(M Y(c)) - h * L,
L = ||Br|| d_F + max_j (C_j + d_j^gfl + d_j^RC)  (||M|| = 1),  d_F, d_j from Lemma 2 (dirb_cont.dparts)."""
import numpy as np, dirb39v2 as M2, dirb_cont as K
from dirb39 import Finv
from testbed9 import w0

def Ypair(s, w):
    F = np.linalg.inv(Finv(1j*w)); Yn = np.kron(s.Br, F); D1 = np.zeros_like(Yn); D0 = np.zeros_like(Yn)
    for j, b in enumerate(s.keep):
        D1[2*j:2*j+2, 2*j:2*j+2] = M2.Ydev(s, b, 1j*w); D0[2*j:2*j+2, 2*j:2*j+2] = M2.Ypas(s, b, 1j*w)
    return Yn + D0, Yn + D1, F

def her(X): return 0.5 * (X + X.conj().T)

def full_M(Y0, Y1):
    lam, T = np.linalg.eig(np.linalg.solve(Y0, Y1)); Ti = np.linalg.inv(T)
    d = np.exp(-1j * np.angle(lam) / 2)
    M = Ti.conj().T @ np.diag(d) @ Ti @ np.linalg.inv(Y0); return M / np.linalg.norm(M, 2)

def margin(M, Y0, Y1):
    return min(np.linalg.eigvalsh(her(M @ Y0))[0], np.linalg.eigvalsh(her(M @ Y1))[0])

def lip(s, c, h, F):
    nF = np.linalg.norm(F, 2); q = h * nF / w0
    if q >= 1: return np.inf
    dF = (nF ** 2 / w0) / (1 - q) ** 2; dmax = 0.0
    for b in s.keep:
        dg, dr = K.dparts(s, b, c, h); dmax = max(dmax, s.C[b] + dg + dr)
    return np.linalg.norm(s.Br, 2) * dF + dmax

def full_interval(s, a, b, stats, depth=0, maxdepth=26):
    c = 0.5 * (a + b); h = 0.5 * (b - a); Y0, Y1, F = Ypair(s, c); stats["evals"] += 1
    M = full_M(Y0, Y1); v = margin(M, Y0, Y1)
    if v <= 0: return False, c
    if v - h * lip(s, c, h, F) > 0: return True, None
    if depth >= maxdepth: return False, c
    ok, where = full_interval(s, a, c, stats, depth + 1, maxdepth)
    if not ok: return ok, where
    return full_interval(s, c, b, stats, depth + 1, maxdepth)

if __name__ == "__main__":
    import sys, time
    from dirb39_probe2 import P0, GFL
    for x in [float(a) for a in sys.argv[1:]]:
        s = M2.build({b: x*P0[b] for b in GFL}, GFL); t0 = time.time(); stats = {"evals": 0}
        grid = np.geomspace(2*np.pi*90, 2*np.pi*300, 200)
        res = None
        for a, b in zip(grid[:-1], grid[1:]):
            ok, where = full_interval(s, a, b, stats)
            if not ok: res = where; break
        print(f"x={x}: full-M band [90,300 Hz] {'CERTIFIED' if res is None else f'fails near {res/2/np.pi:.3f} Hz'}; evals {stats['evals']}; {time.time()-t0:.0f}s; truth maxRe {M2.eig(s).real.max():.2f}", flush=True)

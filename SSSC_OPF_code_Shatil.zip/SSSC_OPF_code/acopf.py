"""Sequential AC-OPF on IEEE 39-bus (model v2), with or without the certified small-signal stability constraint.

Decision x (19): P of sync gens at buses 29, 31, 37, 38; P and Q of GFL units at 32-36; voltage set-points of the
sync gens and the slack (29, 30, 31, 37, 38).  Slack = ext grid at bus 30 (balances P).
Cost: sync units (incl. slack) 0.01 P^2 + 30 P  [$/h, P in MW];  GFL 5 P.
Limits: |V| in [0.94, 1.06] at all buses; line and trafo loading <= 100 %; slack P in [0, 646], slack Q, sync gen Q
within case limits; sync P within [0, Pmax]; GFL P in [0.1, 1.2] P0, P^2 + Q^2 <= S^2 (S = inverter rating).
Method: SLP with trust region and elastic l1 penalty (merit = cost + rho * violation), constraints linearised by
finite differences of the exact AC power flow; a step is accepted only if the TRUE merit decreases (and, with
stability, the continuous-frequency certificate of Theorem B3 holds at the new point)."""
import numpy as np, cvxpy as cp, pandapower as pp, json, time, sys, warnings; warnings.filterwarnings("ignore")
import dirb39v2 as M2, cert_v2 as CV, fast_sdp as FS
from dirb39 import Finv
from dirb39v2 import qbase2 as qbase
from dirb39_probe2 import P0, GFL

import os
LS = float(os.environ.get('LOAD_SCALE', '1.0'))
SYNC = [29, 31, 37, 38]; SLACK = 30; VBUS = [29, 30, 31, 37, 38]
NAMES = [("P", b) for b in SYNC] + [("Pg", b) for b in GFL] + [("Qg", b) for b in GFL] + [("V", b) for b in VBUS]
NX = len(NAMES); RHO = float(os.environ.get('RHO', '1e5'))
_net0, RATING, *_ = M2.make_net({b: P0[b] for b in GFL}, GFL, Q=qbase())
SRAT = {b: RATING[b] for b in GFL}
PMAX = {int(r.bus): float(r.max_p_mw) for _, r in _net0.gen.iterrows()}
QLIM = {int(r.bus): (float(r.min_q_mvar), float(r.max_q_mvar)) for _, r in _net0.gen.iterrows()}
EG = _net0.ext_grid.iloc[0]; SLP = (0.0, float(EG.max_p_mw)); SLQ = (float(EG.min_q_mvar), float(EG.max_q_mvar))

def unpack(x):
    Ps = {b: x[i] for i, b in enumerate(SYNC)}; Pg = {b: x[4 + i] for i, b in enumerate(GFL)}
    Qg = {b: x[9 + i] for i, b in enumerate(GFL)}; Vs = {b: x[14 + i] for i, b in enumerate(VBUS)}
    return Ps, Pg, Qg, Vs

def x_from(Pg_frac=0.8):
    net = _net0
    Ps = [float(net.gen.p_mw[net.gen.bus == b].iloc[0]) for b in SYNC]
    Vs = [float(net.gen.vm_pu[net.gen.bus == b].iloc[0]) if b != SLACK else float(net.ext_grid.vm_pu.iloc[0]) for b in VBUS]
    return np.array(Ps + [Pg_frac * P0[b] for b in GFL] + [qbase()[b] for b in GFL] + Vs)

def pf(x):
    Ps, Pg, Qg, Vs = unpack(x)
    net, *_ = M2.make_net(Pg, GFL, Q=Qg, Psync=Ps, Vset=Vs, load_scale=LS)
    for kw in (dict(init="dc"), dict(init="flat")):
        try: pp.runpp(net, numba=False, max_iteration=100, **kw); return net
        except Exception: continue
    return None

def cost(x, net):
    Ps, Pg, _, _ = unpack(x); sl = float(net.res_ext_grid.p_mw.iloc[0])
    return sum(0.01 * p ** 2 + 30 * p for p in list(Ps.values()) + [sl]) + sum(5 * p for p in Pg.values())

def gvec(net):
    """nonlinear inequality constraints g(x) <= 0 (scaled to pu / fraction)"""
    V = net.res_bus.vm_pu.values; g = [V - 1.06, 0.94 - V]
    g.append(net.res_line.loading_percent.values / 100 - 1); g.append(net.res_trafo.loading_percent.values / 100 - 1)
    sl = net.res_ext_grid; g.append(np.array([(sl.p_mw.iloc[0] - SLP[1]) / 100, (SLP[0] - sl.p_mw.iloc[0]) / 100,
                                              (sl.q_mvar.iloc[0] - SLQ[1]) / 100, (SLQ[0] - sl.q_mvar.iloc[0]) / 100]))
    q = []
    for _, r in net.gen.iterrows():
        b = int(r.bus); qq = float(net.res_gen.q_mvar[_]); q += [(qq - QLIM[b][1]) / 100, (QLIM[b][0] - qq) / 100]
    g.append(np.array(q)); return np.concatenate(g)

def viol(g): return float(np.maximum(g, 0).sum())

STEP = np.array([5.0] * 4 + [5.0] * 5 + [5.0] * 5 + [0.003] * 5)

def sensitivities(x, net):
    g0 = gvec(net); sl0 = float(net.res_ext_grid.p_mw.iloc[0]); Jg = np.zeros((len(g0), NX)); Js = np.zeros(NX)
    for k in range(NX):
        nk = None
        for h in (STEP[k], -STEP[k], STEP[k] / 4, -STEP[k] / 4, STEP[k] / 16, -STEP[k] / 16):
            xk = x.copy(); xk[k] += h; nk = pf(xk)
            if nk is not None: break
        if nk is None: continue
        Jg[:, k] = (gvec(nk) - g0) / h; Js[k] = (float(nk.res_ext_grid.p_mw.iloc[0]) - sl0) / h
    return g0, Jg, sl0, Js

def bk(x):
    Ps, Pg, Qg, Vs = unpack(x); return Pg, dict(Q=Qg, Psync=Ps, Vset=Vs, load_scale=LS)

def stab_model(x, recs, s, nact=12, delta=0.005, margin=None):
    """Schur-reduced (GFL rows) certificate matrices at the active samples and their first-order derivatives in x"""
    keep = s.keep; n = len(keep); gi = [keep.index(b) for b in GFL]
    hm = [FS.verify_H(s, r) for r in recs]; act = sorted(range(len(recs)), key=lambda i: hm[i])[:nact]
    v = margin if margin is not None else min(hm)
    dlt = min(delta, v / 4); tau = v / 4             # tau: margin reserved for load-conductance changes
    var_idx = sorted([2*j for j in gi] + [2*j+1 for j in gi] + [2*n+2*j for j in gi] + [2*n+2*j+1 for j in gi])
    fix_idx = [r for r in range(4 * n) if r not in var_idx]
    Pg, kw = bk(x); sk = []
    for k in range(NX):
        xk = x.copy(); xk[k] += STEP[k]; Pk, kwk = bk(xk)
        try: sk.append(M2.build(Pk, GFL, **kwk))
        except Exception: sk.append(None)
    out = []
    for i in act:
        w, _, ms, owner, _ = recs[i]; F = np.linalg.inv(Finv(1j * w)); Ys = [M2.Ydev(s, b, 1j * w) for b in keep]
        _, H = FS.blocks(F, Ys, s.Br, ms, owner); Mf = H - (dlt + tau) * np.eye(4 * n)
        A0 = Mf[np.ix_(var_idx, var_idx)]; Cc = Mf[np.ix_(var_idx, fix_idx)]; Dk = Mf[np.ix_(fix_idx, fix_idx)]
        Sred = A0 - Cc @ np.linalg.solve(Dk, Cc.T); Sred = 0.5 * (Sred + Sred.T)
        dS = []
        for k in range(NX):
            if sk[k] is None: dS.append(np.zeros_like(Sred)); continue
            dY = np.zeros((2 * n, 2 * n), complex); Mb = np.zeros((2 * n, 2 * n), complex)
            for j in gi:
                b = keep[j]; dY[2*j:2*j+2, 2*j:2*j+2] = (M2.Ydev(sk[k], b, 1j * w) - Ys[j]) / STEP[k]
                Mb[2*j:2*j+2, 2*j:2*j+2] = ms[owner[j]]
            D = FS.realH(Mb @ dY); dS.append(D[np.ix_(var_idx, var_idx)])
        out.append((Sred, dS))
    # load-conductance sensitivities at non-GFL kept buses, weighted by the largest ||Her m_j|| over the active samples
    loads = [b for b in keep if b not in GFL]
    Gs = np.zeros((len(loads), NX))
    for k in range(NX):
        if sk[k] is None: continue
        Gs[:, k] = [(sk[k].g[b] - s.g[b]) / STEP[k] for b in loads]
    wts = np.array([max(np.linalg.norm(FS.her(recs[i][2][recs[i][3][keep.index(b)]]), 2) for i in act) for b in loads])
    return out, dlt, (Gs, wts, tau)

def eig_model(x, thr=-150.0):
    """real parts of near-critical eigenvalues and their finite-difference gradients (modes matched by proximity)"""
    Pg, kw = bk(x); ev = M2.eig(M2.build(Pg, GFL, **kw)); S = ev[(ev.real > thr) & (ev.imag >= 0)]
    G = np.zeros((len(S), NX))
    for k in range(NX):
        xk = x.copy(); xk[k] += STEP[k]; Pk, kwk = bk(xk)
        try: evk = M2.eig(M2.build(Pk, GFL, **kwk))
        except Exception: continue
        for i, l in enumerate(S): G[i, k] = (evk[np.argmin(np.abs(evk - l))].real - l.real) / STEP[k]
    return S.real, G

SPECTRAL = os.environ.get("SPECTRAL", "0") == "1"
SPEC_GRID = 2 * np.pi * np.arange(20.0, 300.0, 0.25)

def Zeigs(s, w):
    import bf_cert as BF
    Y0, Ya, F = BF.parts(s, w); return np.linalg.eigvals(np.eye(len(Y0)) + np.linalg.solve(Y0, Ya))

def spec_model(x, s, phi_sel=0.6):
    """angle margins phi = pi - |arg lam| of eigenvalues of Z(w) near the negative real axis, and their gradients in x"""
    Pg, kw = bk(x); sk = []
    for k in range(NX):
        xk = x.copy(); xk[k] += STEP[k]; Pk, kwk = bk(xk)
        try: sk.append(M2.build(Pk, GFL, **kwk))
        except Exception: sk.append(None)
    phis, grads = [], []
    for w in SPEC_GRID:
        lam = Zeigs(s, w); ph = np.pi - np.abs(np.angle(lam)); sel = np.where(ph < phi_sel)[0]
        if len(sel) == 0: continue
        G = np.zeros((len(sel), NX))
        for k in range(NX):
            if sk[k] is None: continue
            lk = Zeigs(sk[k], w)
            for r, i in enumerate(sel):
                j = np.argmin(np.abs(lk - lam[i])); G[r, k] = ((np.pi - abs(np.angle(lk[j]))) - ph[i]) / STEP[k]
        phis.append(ph[sel]); grads.append(G)
    if not phis: return np.zeros(0), np.zeros((0, NX))
    return np.concatenate(phis), np.vstack(grads)

SIGMA = float(os.environ.get("SIGMA", "0"))

def certify_any(Pg, **kw):
    if SIGMA > 0:
        import bf_shift as BS
        sm = M2.build(Pg, GFL, **kw); r = BS.certify_shift(sm, SIGMA); r["s"] = sm; r["margin"] = r.get("dmin", 0.0); return r
    if SPECTRAL:
        import bf_cert as BF; return BF.cert_spectral(Pg, **kw)
    return CV.certify(Pg, log=lambda m: None, **kw)

def run(x0, stability=True, iters=30, Delta0=100.0, log=print, tag="", phase1=False, gfl_cap=None, eig_accept=None):
    x = x0.copy(); Delta = Delta0
    W = 1e-6 if phase1 else 1.0
    net = pf(x); g = gvec(net); f = cost(x, net); mer = W * f + RHO * viol(g)
    cert = None
    if stability:
        Pg, kw = bk(x); cert = certify_any(Pg, **kw)
        if not cert["certified"]: log(f"{tag} start not certified: {cert['reason']}"); return []
    hist = [dict(x=x.tolist(), cost=f, viol=viol(g), gfl=sum(unpack(x)[1].values()),
                 margin=cert["margin"] if cert else None, stable=bool(M2.eig(cert["s"]).real.max() < 0) if cert else None)]
    log(f"{tag} start: cost {f:.0f} $/h, violation {viol(g):.3f}, GFL {hist[0]['gfl']:.0f} MW" + (f", margin {cert['margin']:.4f}" if cert else ""))
    for it in range(iters):
        g0, Jg, sl0, Js = sensitivities(x, net)
        if stability and SPECTRAL and eig_accept is None: phis, Gphi = spec_model(x, cert["s"])
        elif stability and SPECTRAL: phis, Gphi = np.zeros(0), np.zeros((0, NX))
        elif stability: smod, dlt, (Gs, wts, tau) = stab_model(x, cert["recs"], cert["s"], margin=cert["margin"])
        if eig_accept is not None: lamS, Glam = eig_model(x)
        while True:
            dx = cp.Variable(NX); sv = cp.Variable(len(g0), nonneg=True); X = x + dx
            sc = np.array([1.0] * 14 + [0.02 / 100] * 5)            # trust-region scale: MW/Mvar, and pu per 100 MW
            cons = [cp.abs(dx) <= Delta * sc, g0 + Jg @ dx <= sv]
            for i, b in enumerate(SYNC): cons += [X[i] >= 0, X[i] <= PMAX[b]]
            for i, b in enumerate(GFL):
                cons += [X[4 + i] >= 0.1 * P0[b], X[4 + i] <= 1.2 * P0[b], cp.norm(cp.hstack([X[4 + i], X[9 + i]])) <= SRAT[b]]
            cons += [X[14:] >= 0.94, X[14:] <= 1.06]
            if gfl_cap is not None: cons.append(cp.sum(X[4:9]) <= gfl_cap)
            if eig_accept is not None and len(lamS):
                cons.append(lamS + Glam @ dx <= np.maximum(-eig_accept, lamS))   # keep modes left of -eig_accept (or no worse)
            slp = sl0 + Js @ dx
            obj = W * (sum(0.01 * cp.square(X[i]) + 30 * X[i] for i in range(4)) + 0.01 * cp.square(slp) + 30 * slp
                       + 5 * cp.sum(X[4:9])) + RHO * cp.sum(sv)
            if stability and SPECTRAL:
                if len(phis): cons.append(phis + Gphi @ dx >= np.minimum(phis / 2, 0.02))
            elif stability:
                cons.append(cp.multiply(wts, cp.abs(Gs @ dx)) <= tau)
                for Sred, dS in smod:
                    M = Sred + sum(dx[k] * dS[k] for k in range(NX)); cons.append(0.5 * (M + M.T) >> 0)
            pr = cp.Problem(cp.Minimize(obj), cons)
            try: pr.solve(solver=cp.CLARABEL)
            except Exception:
                try: pr.solve(solver=cp.SCS, eps=1e-7, max_iters=100000)
                except Exception: pass
            if dx.value is None: log(f"{tag} iter {it}: subproblem failed"); return hist
            xc = x + dx.value; nc = pf(xc); ok = nc is not None
            if ok:
                gc = gvec(nc); fc = cost(xc, nc); merc = W * fc + RHO * viol(gc)
                pred = mer - pr.value; ok = merc < mer - 1e-4 * max(pred, 0)
            cc = None; nc_reason = None
            if nc is not None and not ok: nc_reason = f"merit {merc:.0f} vs {mer:.0f}"
            if ok and eig_accept is not None and SIGMA == 0:
                Pg_, kw_ = bk(xc); lam = float(M2.eig(M2.build(Pg_, GFL, **kw_)).real.max()); ok = lam < -eig_accept
                if not ok: nc_reason = f"eigenvalue {lam:.2f}"
            if ok and stability:
                Pg, kw = bk(xc)
                try: cc = certify_any(Pg, **kw)
                except Exception as e: cc = dict(certified=False, reason=str(e)[:50])
                ok = cc["certified"]
            if ok:
                stb = bool(M2.eig(cc["s"]).real.max() < 0) if cc else bool(M2.eig(M2.build(*bk(xc)[:1], GFL, **bk(xc)[1])).real.max() < 0)
                x, net, f, g, mer, cert = xc, nc, fc, gc, merc, (cc or cert)
                hist.append(dict(x=x.tolist(), cost=f, viol=viol(g), gfl=sum(unpack(x)[1].values()),
                                 margin=cc["margin"] if cc else None, stable=stb))
                log(f"{tag} iter {it}: cost {f:.0f}, violation {viol(g):.4f}, GFL {hist[-1]['gfl']:.0f} MW"
                    + (f", margin {cc['margin']:.4f}" if cc else "") + f", truth stable {stb}, Delta {Delta:.1f}")
                json.dump(hist, open(f"acopf_{tag.strip('[]')}_L{int(LS*100)}_partial.json", "w"), indent=1, default=float)
                if phase1 and viol(g) < 1e-4: log(f"{tag} feasible: phase 1 done"); return hist
                if np.abs(dx.value[:14]).max() < 0.5 and viol(g) < 1e-6: return hist
                Delta = min(Delta * 1.5, Delta0); break
            step = np.max(np.abs(dx.value) / sc); Delta = min(Delta, step) / 2
            why = "no AC solution" if nc is None else (nc_reason or "merit not decreased") if cc is None else f"not certified ({cc.get('reason','')})"
            log(f"{tag} iter {it}: rejected ({why}); Delta -> {Delta:.1f}")
            if Delta < 0.5: log(f"{tag} trust region collapsed"); return hist
    return hist

if __name__ == "__main__":
    mode = sys.argv[1]; t0 = time.time()
    if sys.argv[2].endswith(".json"):
        x0 = np.array(json.load(open(sys.argv[2]))[-1]["x"]); name = f"acopf_{mode}_resume.json"
    else:
        frac = float(sys.argv[2]); x0 = x_from(frac); name = f"acopf_{mode}_{int(frac*100)}_L{int(LS*100)}.json"
    if mode == "certeig":
        h = run(x0, stability=True, eig_accept=float(os.environ.get('EIGM', '0.2')), iters=80, log=lambda m: print(m, flush=True), tag="[certeig]")
        name = f"acopf_certeig_L{int(LS*100)}.json"
    elif mode == "stab3":
        cap = float(os.environ.get("CAP", "2300")); h1 = None
        while cap > 1000:
            hc = run(x0, stability=False, phase1=True, gfl_cap=cap, iters=40, log=lambda m: None, tag="[cap]")
            xc = np.array(hc[-1]["x"]); Pg_, kw_ = bk(xc)
            cc = certify_any(Pg_, **kw_) if hc[-1]["viol"] < 1e-4 else dict(certified=False, reason="infeasible")
            print(f"[stab3-p1] cap {cap:.0f} MW: violation {hc[-1]['viol']:.5f}, certified {cc['certified']} {cc.get('reason','')}", flush=True)
            if cc["certified"]: h1 = hc; break
            cap -= 100
        json.dump(h1, open(f"acopf_stab3_phase1_L{int(LS*100)}.json", "w"), indent=1, default=float)
        h = run(np.array(h1[-1]["x"]), stability=True, log=lambda m: print(m, flush=True), tag="[stab3-p2]")
        name = f"acopf_stab3_L{int(LS*100)}.json"
    elif mode == "eig":
        h = run(x0, stability=False, eig_accept=float(os.environ.get('EIGM', '1.0')), iters=80, log=lambda m: print(m, flush=True), tag="[eig]")
        name = name.replace("acopf_eig", "acopf_eig")
    elif mode == "stab2":
        h1 = run(x0, stability=True, log=lambda m: print(m, flush=True), tag="[stab2-p1]", phase1=True)
        json.dump(h1, open(f"acopf_stab2_phase1_L{int(LS*100)}.json", "w"), indent=1, default=float)
        h = run(np.array(h1[-1]["x"]), stability=True, log=lambda m: print(m, flush=True), tag="[stab2-p2]")
        name = f"acopf_stab2_L{int(LS*100)}.json"
    else:
        h = run(x0, stability=(mode == "stab"), log=lambda m: print(m, flush=True), tag=f"[{mode}]")
    json.dump(h, open(name, "w"), indent=1, default=float)
    print(f"done in {(time.time()-t0)/60:.1f} min", flush=True)

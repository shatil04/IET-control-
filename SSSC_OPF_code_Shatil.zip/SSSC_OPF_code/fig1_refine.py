import numpy as np, json, dirb39v2 as M2, bf_cert as BF
from dirb39_probe2 import P0, GFL
s = M2.build({b: 0.85*P0[b] for b in GFL}, GFL)
def dist(f):
    Y0, Ya, F = BF.parts(s, 2*np.pi*f); lam = np.linalg.eigvals(np.eye(len(Y0)) + np.linalg.solve(Y0, Ya))
    i = np.argmin(BF.distneg(lam)); return float(BF.distneg(lam)[i]), lam[i]
fs = np.arange(117.50, 117.58, 0.0005); r = [dist(f) for f in fs]
k = int(np.argmin([a for a, _ in r])); print("finest min", r[k][0], "at", round(fs[k], 4), "lam", np.round(r[k][1], 5))
# where does Im(lam) change sign while Re<0 ?
im = [l.imag for _, l in r]; re = [l.real for _, l in r]
for i in range(len(fs)-1):
    if np.sign(im[i]) != np.sign(im[i+1]) and re[i] < 0: print("sign change of Im between", round(fs[i],4), round(fs[i+1],4), "Re", round(re[i],4))
d = json.load(open("fig1_data.json")); d["0.85_zoom"] = dict(f=fs.round(4).tolist(), d=[a for a, _ in r]); json.dump(d, open("fig1_data.json", "w"))

"""Area-wise (sparse) multipliers for the homotopy certificate (between Theorem 1(a) block-diagonal and Prop. 3 full).
M(w) = blkdiag_k M_k, M_k a FULL complex matrix on the 2|A_k| dq-coordinates of area A_k.
Certify frequency w if  Her(M Y0) > 0  and  Her(M Y1) > 0   (Y0 passive reference, Y1 full system; convexity in alpha).
Areas: spectral clustering of the reduced (Kron) network Laplacian B_r."""
import numpy as np, cvxpy as cp
import dirb39v2 as M2
from dirb39 import Finv

def areas_spectral(Br, k, keep=None, seed=0):
    """k electrical areas by normalised spectral clustering of the reduced susceptance Laplacian (k-means, fixed seed)."""
    W = np.abs(Br - np.diag(np.diag(Br))); d = W.sum(1); Dm = np.diag(1 / np.sqrt(d))
    L = np.eye(len(W)) - Dm @ W @ Dm; ev, V = np.linalg.eigh(L); X = V[:, :k]; X /= np.linalg.norm(X, axis=1, keepdims=True)
    rng = np.random.default_rng(seed); best = None
    for _ in range(50):
        C = X[rng.choice(len(X), k, replace=False)]
        for _ in range(100):
            lab = np.argmin(((X[:, None] - C[None]) ** 2).sum(-1), 1)
            C2 = np.array([X[lab == i].mean(0) if np.any(lab == i) else C[i] for i in range(k)])
            if np.allclose(C2, C): break
            C = C2
        inert = ((X - C[lab]) ** 2).sum()
        if best is None or inert < best[0]: best = (inert, lab.copy())
    return best[1]

def mats(s, w):
    sl = 1j * w; F = np.linalg.inv(Finv(sl)); Yn = np.kron(s.Br, F); n = len(s.keep)
    Yp = np.zeros_like(Yn); Yd = np.zeros_like(Yn)
    for j, b in enumerate(s.keep):
        Yp[2*j:2*j+2, 2*j:2*j+2] = M2.Ypas(s, b, sl); Yd[2*j:2*j+2, 2*j:2*j+2] = M2.Ydev(s, b, sl)
    return Yn + Yp, Yn + Yd

def idx_of(lab, a):
    js = np.where(lab == a)[0]; return np.sort(np.concatenate([2 * js, 2 * js + 1]))

def her(X): return 0.5 * (X + X.conj().T)

def solve_area(Y0, Y1, lab, verbose=False):
    """max t: Her(M Y0) >= t I, Her(M Y1) >= t I, M area-block-diagonal, |M_ij| <= 1 elementwise. Returns (t, M)."""
    m = Y0.shape[0]; sc = 1 / np.abs(Y1).max(); Y0s, Y1s = Y0 * sc, Y1 * sc
    blocks = []; parts0 = 0; parts1 = 0
    for a in np.unique(lab):
        I = idx_of(lab, a); Mk = cp.Variable((len(I), len(I)), complex=True); blocks.append((I, Mk))
        P = np.zeros((len(I), m)); P[np.arange(len(I)), I] = 1
        parts0 = parts0 + P.T @ Mk @ (P @ Y0s); parts1 = parts1 + P.T @ Mk @ (P @ Y1s)
    t = cp.Variable(); H0 = 0.5 * (parts0 + parts0.H); H1 = 0.5 * (parts1 + parts1.H)
    cons = [H0 - t * np.eye(m) >> 0, H1 - t * np.eye(m) >> 0] + [cp.abs(Mk) <= 1 for _, Mk in blocks]
    pr = cp.Problem(cp.Maximize(t), cons)
    try: pr.solve(solver=cp.CLARABEL, verbose=verbose)
    except Exception:
        try: pr.solve(solver=cp.SCS, eps=1e-8, max_iters=50000)
        except Exception: return -np.inf, None
    if t.value is None: return -np.inf, None
    M = np.zeros((m, m), complex)
    for I, Mk in blocks: M[np.ix_(I, I)] = Mk.value
    return float(t.value), M

def verify(Y0, Y1, M):
    """exact margin: min lambda_min of the two Hermitian parts, multiplier normalised to spectral norm 1"""
    M = M / np.linalg.norm(M, 2)
    return min(np.linalg.eigvalsh(her(M @ Y0))[0], np.linalg.eigvalsh(her(M @ Y1))[0]) / np.linalg.norm(Y1, 2)

def spectral_ok(Y0, Y1):
    lam = np.linalg.eigvals(np.linalg.solve(Y0, Y1)); d = np.where(lam.real >= 0, np.abs(lam), np.abs(lam.imag)); return float(d.min())

# ---------------- direct Clarabel form (fast) ----------------
import scipy.sparse as sp, clarabel
from fast_sdp import svec, realH

def solve_area_fast(Y0, Y1, lab, verbose=False):
    """same SDP, normalisation ||M_k||_F <= 1 per area (SOC). Variables: Re/Im of each area-block entry, then t."""
    m = Y0.shape[0]; sc = 1 / np.abs(Y1).max(); Ys = (Y0 * sc, Y1 * sc)
    var = []                                     # (area, p, q) global row p, col q
    for a in np.unique(lab):
        I = idx_of(lab, a); var += [(a, p, q) for p in I for q in I]
    nv = 2 * len(var) + 1; it = nv - 1; k = 2 * m; L = k * (k + 1) // 2
    rows_A, rows_b, cones = [], [], []
    for Y in Ys:
        cols = []
        for (a, p, q) in var:
            X = np.zeros((m, m), complex); X[p, :] = Y[q, :]
            cols.append(-svec(realH(X))); cols.append(-svec(realH(1j * X)))
        cols.append(svec(np.eye(k)))
        rows_A.append(sp.csc_matrix(np.array(cols).T)); rows_b.append(np.zeros(L)); cones.append(clarabel.PSDTriangleConeT(k))
    for a in np.unique(lab):
        ids = [i for i, v in enumerate(var) if v[0] == a]; A_ = np.zeros((1 + 2 * len(ids), nv)); bb = np.zeros(1 + 2 * len(ids)); bb[0] = 1
        for r, i in enumerate(ids): A_[1 + 2 * r, 2 * i] = -1; A_[2 + 2 * r, 2 * i + 1] = -1
        rows_A.append(sp.csc_matrix(A_)); rows_b.append(bb); cones.append(clarabel.SecondOrderConeT(1 + 2 * len(ids)))
    A_ = sp.vstack(rows_A).tocsc(); b = np.concatenate(rows_b); qv = np.zeros(nv); qv[it] = -1
    st = clarabel.DefaultSettings(); st.verbose = verbose; st.max_iter = 200
    sol = clarabel.DefaultSolver(sp.csc_matrix((nv, nv)), qv, A_, b, cones, st).solve()
    if sol.x is None or not np.all(np.isfinite(sol.x)): return -np.inf, None
    x = np.array(sol.x); M = np.zeros((m, m), complex)
    for i, (a, p, q) in enumerate(var): M[p, q] = x[2 * i] + 1j * x[2 * i + 1]
    return float(x[it]), M

def bus_scaling(Y1):
    """real positive per-bus scaling D (2x2 identity blocks): d_j = ||Y1_jj||^-1/2. Her(M~ D Y D) > 0  <=>  Her(M Y) > 0
    with M = D^-1 M~ D, which keeps the area-block (and block-diagonal) structure."""
    n = Y1.shape[0] // 2; d = np.repeat([1 / np.sqrt(np.linalg.norm(Y1[2*j:2*j+2, 2*j:2*j+2], 2)) for j in range(n)], 2); return d

def solve_area_scaled(Y0, Y1, lab):
    d = bus_scaling(Y1); D = np.diag(d)
    t, Mt = solve_area_fast(D @ Y0 @ D, D @ Y1 @ D, lab)
    if Mt is None: return t, None
    return t, np.diag(1 / d) @ Mt @ D

def verify_scaled(Y0, Y1, M):
    """sign-exact margin in the scaled coordinates (well conditioned): lambda_min Her(M~ Y~) with ||M~|| = 1"""
    d = bus_scaling(Y1); D = np.diag(d); Mt = D @ M @ np.diag(1 / d); Mt /= np.linalg.norm(Mt, 2)
    Y0t, Y1t = D @ Y0 @ D, D @ Y1 @ D; s_ = np.linalg.norm(Y1t, 2)
    return min(np.linalg.eigvalsh(her(Mt @ Y0t))[0], np.linalg.eigvalsh(her(Mt @ Y1t))[0]) / s_

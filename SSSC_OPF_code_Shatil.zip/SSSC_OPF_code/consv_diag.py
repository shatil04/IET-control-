"""Where does conservatism come from? At failing samples compare:
 (A) exact homotopy test: eig(Y0^-1 Y1) avoids (-inf, 0]  (centralised, necessary+sufficient along the homotopy)
 (B) hybrid multipliers (current), (C) per-bus multipliers (each bus own m_j), first-order ascent."""
import numpy as np, sys, time, json, dirb39v2 as M2, fast_sdp as FS
from dirb39 import Finv
from dirb39_probe2 import P0, GFL
def mats(s, w):
    F = np.linalg.inv(Finv(1j*w)); Ys = [M2.Ydev(s,b,1j*w) for b in s.keep]; Yp = [M2.Ypas(s,b,1j*w) for b in s.keep]
    n = len(Ys); Yn = np.kron(s.Br, F); D1 = np.zeros_like(Yn); D0 = np.zeros_like(Yn)
    for j in range(n): D1[2*j:2*j+2,2*j:2*j+2] = Ys[j]; D0[2*j:2*j+2,2*j:2*j+2] = Yp[j]
    return F, Ys, Yp, Yn + D0, Yn + D1
def exact(Y0, Y1):
    ev = np.linalg.eigvals(np.linalg.solve(Y0, Y1))
    neg = ev[(np.abs(ev.imag) < 1e-9 * np.abs(ev).max()) & (ev.real <= 0)]
    # distance of spectrum from the negative real axis (angle margin)
    ang = np.min(np.pi - np.abs(np.angle(ev)))
    return len(neg) == 0, ang
if __name__ == "__main__":
  cases = {"u80": ({b: 0.8*P0[b] for b in GFL}, {}), "u85(unstable)": ({b: 0.85*P0[b] for b in GFL}, {})}
  fr = [float(f) for f in sys.argv[1:]] or [60.381, 67.836, 76.212, 85.622, 96.194, 108.071, 121.414]
  for name, (P, kw) in cases.items():
      s = M2.build(P, GFL, **kw); special = [s.keep.index(b) for b in GFL]; n = len(s.keep)
      for f in fr:
          w = 2*np.pi*f; F, Ys, Yp, Y0, Y1 = mats(s, w); ok, ang = exact(Y0, Y1)
          t0 = time.time(); vh, mo, mode = FS.step_block(F, Ys, s.Br, special, Ypas=Yp); th = time.time()-t0
          own = {j: j for j in range(n)}; t0 = time.time()
          start = [mo[0][mo[1][j]] for j in range(n)] if mo is not None else np.eye(2)/np.sqrt(2)
          mp = FS.hybrid_ascent(F, Ys, s.Br, own, n, start, Ypas=Yp); nm = max(np.linalg.norm(m,2) for m in mp); mp = [m/nm for m in mp]
          vp = FS.verify_block(F, Ys, s.Br, mp, own, Yp); tp = time.time()-t0
          print(f"{name:14s} {f:8.2f} Hz | exact homotopy ok {ok} (angle margin {ang:.3f} rad) | hybrid {vh:+.4f} ({th:.0f}s) | per-bus {vp:+.4f} ({tp:.0f}s)", flush=True)

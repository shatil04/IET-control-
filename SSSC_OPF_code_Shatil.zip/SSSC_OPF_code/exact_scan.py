import numpy as np, sys, dirb39v2 as M2
from consv_diag import mats, exact
from dirb39_probe2 import P0, GFL
for x in [0.8, 0.85]:
    s = M2.build({b: x*P0[b] for b in GFL}, GFL); ev = M2.eig(s); i = np.argmax(ev.real)
    fs = np.concatenate([[0.0], np.geomspace(1e-3, 3e4, 4000)]); bad = []
    for f in fs:
        ok, ang = exact(*mats(s, 2*np.pi*f)[3:]);
        if not ok: bad.append(f)
    print(x, "lam_max", np.round(ev[i], 2), f"({abs(ev[i].imag)/2/np.pi:.1f} Hz)", "exact test fails at", (round(min(bad),2), round(max(bad),2), len(bad)) if bad else "none")

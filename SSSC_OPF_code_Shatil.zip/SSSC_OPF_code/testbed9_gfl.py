"""9-bus testbed with mixed units: GFL (PLL + current loop) at chosen generator buses, droop GFM elsewhere.
Adds grid-weakness scaling (all branch impedances x kw) and GFL redispatch, to find operating-point-driven
instability. Reuses the consistent electromagnetic network model of testbed9."""
import numpy as np, pandapower as pp, pandapower.networks as pn, warnings
warnings.filterwarnings("ignore")
import testbed9 as T
from testbed9 import J, I2, w0, rot, gfm_local

def jac(fun, a, b, wx, h=1e-7):
    base = fun(a, b) if wx else fun(b, a); M = np.zeros((len(base), len(a)))
    for k in range(len(a)):
        da = np.zeros(len(a)); da[k] = h
        M[:, k] = ((fun(a + da, b) if wx else fun(b, a + da)) - base) / h
    return M

def gfl_local(V, P, Q, f_pll=20.0, zeta=0.7, tau_c=1e-3):
    """GFL in local frame (v0=[V,0]). States: theta_pll, xi (PI integral), ic_d, ic_q (PLL frame).
    Input v (local), output delivered current (local)."""
    wn = 2 * np.pi * f_pll; kp = 2 * zeta * wn / V; ki = wn ** 2 / V
    iref = np.array([P / V, -Q / V]); x0 = np.array([0., 0., *iref]); v0 = np.array([V, 0.])
    def vq(x, v): return -np.sin(x[0]) * v[0] + np.cos(x[0]) * v[1]
    def f(x, v):
        q = vq(x, v); return np.array([kp * q + x[1], ki * q, *((-x[2:] + iref) / tau_c)])
    def g(x, v): return rot(x[0]) @ x[2:]
    return jac(f, x0, v0, True), jac(f, v0, x0, False), jac(g, x0, v0, True), jac(g, v0, x0, False)

def build(gfl_buses=(1,), p_gfl=None, kw=1.0, mp=0.05, Xv=0.1, Rv=0.05, mq=0.05, fc=5.0, Sdev=250.,
          f_pll=20.0, tau_c=1e-3, cf_dev=0.05, load_scale=1.0):
    net = pn.case9(); net.load.p_mw *= load_scale; net.load.q_mvar *= load_scale
    kk = Sdev / net.sn_mva
    for b in net.bus.index:
        extra = cf_dev * kk if b in gfl_buses else 0.0
        pp.create_shunt(net, b, q_mvar=-(1e-4 + extra) * net.sn_mva, p_mw=0.0)
    net.line.r_ohm_per_km *= kw; net.line.x_ohm_per_km *= kw
    net.trafo.vk_percent *= kw; net.trafo.vkr_percent *= kw
    if p_gfl is not None:
        for i in net.gen.index:
            if int(net.gen.bus[i]) in gfl_buses: net.gen.loc[i, "p_mw"] = p_gfl
    pp.runpp(net, numba=False, max_iteration=50)
    base = net.sn_mva; n = len(net.bus)
    V = net.res_bus.vm_pu.values; th = np.deg2rad(net.res_bus.va_degree.values)
    br, Cb = [], np.full(n, 1e-4 / w0)
    for b in gfl_buses: Cb[b] += cf_dev * (Sdev / base) / w0
    for _, l in net.line.iterrows():
        z = net.bus.vn_kv[l.from_bus] ** 2 / base
        R = l.r_ohm_per_km * l.length_km / z; X = l.x_ohm_per_km * l.length_km / z
        Bsh = 2 * np.pi * net.f_hz * l.c_nf_per_km * 1e-9 * l.length_km * z
        br.append((l.from_bus, l.to_bus, R, X / w0)); Cb[l.from_bus] += Bsh / 2 / w0; Cb[l.to_bus] += Bsh / 2 / w0
    for _, t in net.trafo.iterrows():
        zk = t.vk_percent / 100 * base / t.sn_mva; r = t.vkr_percent / 100 * base / t.sn_mva
        br.append((t.hv_bus, t.lv_bus, r, np.sqrt(zk ** 2 - r ** 2) / w0))
    g = np.zeros(n); bl = np.zeros(n)
    for _, ld in net.load.iterrows():
        g[ld.bus] += ld.p_mw / base / V[ld.bus] ** 2; bl[ld.bus] += ld.q_mvar / base / V[ld.bus] ** 2
    lb = [j for j in range(n) if bl[j] > 0]; m = len(br); Bi = np.zeros((n, m))
    for k, (f, t, *_) in enumerate(br): Bi[f, k] = 1; Bi[t, k] = -1
    gens = [(int(net.ext_grid.bus[0]), net.res_ext_grid.p_mw[0], net.res_ext_grid.q_mvar[0])]
    gens += [(int(net.gen.bus[i]), net.res_gen.p_mw[i], net.res_gen.q_mvar[i]) for i in net.gen.index]
    k = Sdev / base; devs = []
    for (b, P, Q) in gens:
        if b in gfl_buses: A, Bd, C, D = gfl_local(V[b], P / base / k, Q / base / k, f_pll=f_pll, tau_c=tau_c)
        else: A, Bd, C, D = gfm_local(V[b], P / base / k, Q / base / k, Rv, Xv, mp, mq, fc)
        Rt = rot(th[b]); devs.append((b, A, Bd @ Rt.T, k * Rt @ C, k * Rt @ D @ Rt.T))
    info = dict(P={b: P for b, P, Q in gens}, Q={b: Q for b, P, Q in gens}, V=V, th=th)
    return dict(n=n, br=br, Cb=Cb, g=g, bl=bl, lb=lb, Bi=Bi, devs=devs, V=V, info=info)

def abscissa(sys):
    ev = T.closed_loop(sys); k0 = np.argmin(np.abs(ev)); gauge = abs(ev[k0]); ev = np.delete(ev, k0)
    # drop the network's own electromagnetic mode family near +-j w0 only if far from control range? keep all.
    k = np.argmax(ev.real); return ev[k], gauge

if __name__ == "__main__":
    print("GFL at bus 2 (index 1), GFM at buses 1 and 3. Max real part of non-gauge eigenvalues.")
    print("kw   P_gfl(MW)   max Re      freq(Hz)   gauge|eig|")
    for kw in [1, 1.5, 2, 2.5]:
        for p in [50, 100, 163, 220]:
            try:
                s = build(kw=kw, p_gfl=p); e, ga = abscissa(s)
                print(f"{kw:4.1f}   {p:6d}    {e.real:9.3f}   {abs(e.imag)/2/np.pi:7.1f}    {ga:.1e}")
            except Exception as ex:
                print(f"{kw:4.1f}   {p:6d}    power flow failed ({type(ex).__name__})")

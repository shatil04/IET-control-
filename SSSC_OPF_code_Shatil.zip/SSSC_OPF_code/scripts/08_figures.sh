#!/usr/bin/env bash
# Run from anywhere; works in the package root. Logs go to logs/.
set -e
cd "$(dirname "$0")/.."
mkdir -p logs
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
# Figures 1-2 and the graphical abstract (vector PDF/EPS and PNG) from the files in results/.
python3 make_fig2_data.py
python3 make_figs.py      # -> figs/

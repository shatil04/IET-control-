#!/usr/bin/env bash
# Run from anywhere; works in the package root. Logs go to logs/.
set -e
cd "$(dirname "$0")/.."
mkdir -p logs
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
# Section 7.3: certified OPF, DC-cost variant, from 60 % and 75 % uniform output.
python3 -u dirb39_opf_v2.py 0.6  | tee logs/03_dc_opf_60.log    # -> opf_v3_start60.json
python3 -u dirb39_opf_v2.py 0.75 | tee logs/03_dc_opf_75.log    # -> opf_v3_start75.json

#!/usr/bin/env bash
# Run from anywhere; works in the package root. Logs go to logs/.
set -e
cd "$(dirname "$0")/.."
mkdir -p logs
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
# Section 5.5 / Theorem 4: certified damping margin (Re lambda < -sigma).
python3 -u bf_shift.py 0.8 0 5 10 | tee logs/06_validation_80.log                                   # uniform 80 %: sigma = 0, 5 certified; 10 rejected
LOAD_SCALE=0.9 python3 -u cert_shift_pt.py results/acopf_eig_L90.json 0.9          | tee -a logs/06_optima.log
LOAD_SCALE=1.0 python3 -u cert_shift_pt.py results/acopf_eig_L100.json 0.9         | tee -a logs/06_optima.log
LOAD_SCALE=0.9 python3 -u cert_shift_pt.py results/acopf_certeig_s0_L90.json 0.1   | tee -a logs/06_optima.log
LOAD_SCALE=1.0 python3 -u cert_shift_pt.py results/acopf_certeig_s0_L100.json 0.1  | tee -a logs/06_optima.log
# Optional (slow, hours): certified OPF with sigma = 1 at 90 % load
# LOAD_SCALE=0.9 RHO=1e6 SPECTRAL=1 SIGMA=1.0 EIGM=1.05 python3 -u acopf.py certeig results/acopf_stab3_phase1_L90.json | tee logs/06_sigma1_90.log

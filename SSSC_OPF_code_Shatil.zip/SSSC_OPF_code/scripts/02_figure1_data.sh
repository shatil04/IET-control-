#!/usr/bin/env bash
# Run from anywhere; works in the package root. Logs go to logs/.
set -e
cd "$(dirname "$0")/.."
mkdir -p logs
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
# Figure 1: distance of spec(Y0^-1 Y1) from (-inf, 0] near 117.5 Hz, 80 % and 85 % output, then a 1 mHz zoom.
python3 -u fig1_data.py   | tee logs/02_fig1_data.log
python3 -u fig1_refine.py | tee -a logs/02_fig1_data.log
mv fig1_data.json results/fig1_data.json

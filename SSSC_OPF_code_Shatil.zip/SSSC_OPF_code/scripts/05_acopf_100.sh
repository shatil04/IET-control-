#!/usr/bin/env bash
# Run from anywhere; works in the package root. Logs go to logs/.
set -e
cd "$(dirname "$0")/.."
mkdir -p logs
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
# Section 7.4, 100 % load.
export LOAD_SCALE=1.0 RHO=1e6
python3 -u capfeas.py 2300 | tee logs/05_capfeas.log                                               # feasible start with GFL output capped at 2,300 MW -> capfeas_2300.json
python3 -u acopf.py plain 0.8 | tee logs/05_plain_100.log
EIGM=1.0 python3 -u acopf.py eig capfeas_2300.json | tee logs/05_eig_100.log
SPECTRAL=1 EIGM=0.2 python3 -u acopf.py certeig capfeas_2300.json | tee logs/05_certeig_100.log

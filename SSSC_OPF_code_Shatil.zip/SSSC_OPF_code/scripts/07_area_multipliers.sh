#!/usr/bin/env bash
# Run from anywhere; works in the package root. Logs go to logs/.
set -e
cd "$(dirname "$0")/.."
mkdir -p logs
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
# Section 5.6 / Proposition 4: block-diagonal vs area-wise (2, 3, 4 areas) vs exact test, 0.1-300 Hz (about 1.5 h).
LOAD_SCALE=0.9 python3 -u area_probe.py results/acopf_eig_L90.json 2 3 4 | tee logs/07_area.log   # -> acopf_eig_L90_areaprobe.json

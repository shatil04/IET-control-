#!/usr/bin/env bash
# Run from anywhere; works in the package root. Logs go to logs/.
set -e
cd "$(dirname "$0")/.."
mkdir -p logs
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
# Section 7.4, 90 % load.  Each run writes acopf_<mode>_*.json in the package root.
export LOAD_SCALE=0.9 RHO=1e6
python3 -u acopf.py plain 0.6 | tee logs/04_plain_90.log                                           # plain (unstable) optimum
EIGM=1.0 python3 -u acopf.py eig results/start_L90_feasible.json | tee logs/04_eig_90.log           # eigenvalue baseline, Re(lambda) <= -1
python3 -u acopf.py stab results/start_L90_feasible.json | tee logs/04_structured_90.log           # structured (decentralised) certificate
SPECTRAL=1 CAP=2300 python3 -u acopf.py stab3 0.6 | tee logs/04_spectral_90.log                    # spectral step model; also writes acopf_stab3_phase1_L90.json
SPECTRAL=1 EIGM=0.2 python3 -u acopf.py certeig results/acopf_stab3_phase1_L90.json | tee logs/04_certeig_90.log   # certified, eigenvalue-guided

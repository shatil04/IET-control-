#!/usr/bin/env bash
# Run from anywhere; works in the package root. Logs go to logs/.
set -e
cd "$(dirname "$0")/.."
mkdir -p logs
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
# Section 7.2: uniform scaling of the five grid-following units, 60-85 % of nominal output.
# Tiered certificate (structured multipliers, spectral test where they fail) against eigenvalue ground truth.
python3 -u cert_v2.py 0.6 0.7 0.75 0.8 0.85 | tee logs/01_certificate_scan.log      # -> cert_tiered_scan.json

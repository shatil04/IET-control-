"""Model v2 for IEEE 39-bus Direction B: certificate model == ground-truth model, no jw-axis device poles.
Changes w.r.t. dirb39 (v1):
  * inductive loads: grounded series R-L branch with the SAME R/X = EPS as the network (power-matched:
    1/X = bl (1+EPS^2), its conductance EPS*bl is taken out of the load conductance; pandapower load P is raised
    where P < EPS*Q so that the split is exact)  -> folded into B_r, no device pole at 50 Hz
  * capacitive loads: shunt capacitance C = -bl/w0 (was ignored in v1)
  * C_min only at KEPT buses (loads, GFL); all other buses carry no shunt, so the Kron reduction of the
    uniform-R/X network is EXACT: Y_net,red = Kron(B) (x) F_eps.  Ground truth is built on the same reduced network.
"""
import numpy as np, pandapower as pp, pandapower.networks as pn, warnings
warnings.filterwarnings("ignore")
import testbed9_gfl as G
from testbed9 import J, I2, w0, rot
from dirb39 import EPS, BASE, CMIN, XS_DEV, WS, qbase, Finv, hmin

class Sys: pass

LOAD_FROZEN = True   # loads' small-signal admittance at V = 1 pu: B_r and load blocks independent of dispatch
CAPS = True     # restore removed line charging as capacitor banks at kept buses (PF and dynamic model)

def charging_banks(net, keep):
    """line charging (Mvar at 1 pu) per line end, moved to the kept bus itself or an adjacent kept bus"""
    q = {}
    adj = {}
    for _, l in net.line.iterrows():
        adj.setdefault(int(l.from_bus), []).append(int(l.to_bus)); adj.setdefault(int(l.to_bus), []).append(int(l.from_bus))
    for _, t in net.trafo.iterrows():
        adj.setdefault(int(t.hv_bus), []).append(int(t.lv_bus)); adj.setdefault(int(t.lv_bus), []).append(int(t.hv_bus))
    for _, l in net.line.iterrows():
        v = net.bus.vn_kv[l.from_bus]; b = 2 * np.pi * 50 * l.c_nf_per_km * 1e-9 * l.length_km * l.parallel * v ** 2
        for e in (int(l.from_bus), int(l.to_bus)):
            tgt = e if e in keep else next((k for k in adj.get(e, []) if k in keep), None)
            if tgt is None:                                      # two hops
                tgt = next((k2 for k in adj.get(e, []) for k2 in adj.get(k, []) if k2 in keep), None)
            q[tgt] = q.get(tgt, 0.0) + b / 2
    return q

_QB2 = {}
def qbase2():
    """base-case reactive output of the generators on the v2 network (uniform R/X, no charging, charging banks)"""
    if not _QB2:
        net = pn.case39(); keep = sorted({32, 33, 34, 35, 36} | set(int(b) for b in net.load.bus))
        banks = charging_banks(net, keep) if CAPS else {}
        net.line.r_ohm_per_km = EPS * net.line.x_ohm_per_km; net.line.c_nf_per_km = 0.0
        vk = net.trafo.vk_percent.values; net.trafo.vkr_percent = vk * EPS / np.sqrt(1 + EPS ** 2)
        for b, qc in banks.items(): pp.create_shunt(net, b, q_mvar=-qc, p_mw=0.0)
        pp.runpp(net, numba=False, init="dc", max_iteration=60)
        _QB2.update({int(b): float(q) for b, q in zip(net.gen.bus, net.res_gen.q_mvar)})
    return _QB2

def make_net(P, gfl, kt=3.0, sdev=None, Q=None, load_scale=1.0, Psync=None, Vset=None):
    """pandapower net of model v2 (not yet solved). Psync: {bus: MW} for synchronous gens; Vset: {bus: pu}."""
    net = pn.case39(); net.load.p_mw *= load_scale; net.load.q_mvar *= load_scale
    _keep0 = sorted(set(gfl) | set(int(b) for b in net.load.bus))
    banks = charging_banks(net, _keep0) if CAPS else {}
    lowp = net.load.q_mvar > 0
    net.load.loc[lowp, "p_mw"] = np.maximum(net.load.p_mw[lowp], EPS * net.load.q_mvar[lowp] * 1.0001)
    net.line.r_ohm_per_km = EPS * net.line.x_ohm_per_km; net.line.c_nf_per_km = 0.0
    vk = net.trafo.vk_percent.values; net.trafo.vkr_percent = vk * EPS / np.sqrt(1 + EPS ** 2)
    if "shunt" in net and len(net.shunt): net.shunt.drop(net.shunt.index, inplace=True)
    for b in gfl:
        idx = net.trafo.index[(net.trafo.lv_bus == b) | (net.trafo.hv_bus == b)]
        net.trafo.loc[idx, "vk_percent"] *= kt; net.trafo.loc[idx, "vkr_percent"] *= kt
    rating = {int(net.gen.bus[i]): max(net.gen.p_mw[i] * 1.25, 300.0) for i in net.gen.index}
    sdev = sdev or {b: rating[b] for b in gfl}
    net.gen.drop(net.gen.index[net.gen.bus.isin(gfl)], inplace=True)
    cf = {b: 0.05 * (sdev[b] / BASE) / w0 for b in gfl}; rd = {b: 1.0 / (2 * np.pi * 180 * cf[b]) for b in gfl}
    for b in gfl:
        pp.create_sgen(net, b, p_mw=P[b], q_mvar=(Q or qbase2())[b])
        yd = 1 / (rd[b] + 1 / (1j * w0 * cf[b]))
        pp.create_shunt(net, b, p_mw=yd.real * BASE, q_mvar=-(yd.imag + w0 * cf[b]) * BASE)
    n = len(net.bus)
    g = np.zeros(n); bl = np.zeros(n)
    loadbus = set(int(b) for b in net.load.bus)
    keep = sorted(set(gfl) | loadbus)
    for b in keep: pp.create_shunt(net, b, q_mvar=-w0 * CMIN * BASE, p_mw=0.0)
    for b, qc in banks.items(): pp.create_shunt(net, b, q_mvar=-qc, p_mw=0.0, name="cap")
    for i in net.gen.index:
        b = int(net.gen.bus[i])
        if Psync and b in Psync: net.gen.loc[i, "p_mw"] = Psync[b]
        if Vset and b in Vset: net.gen.loc[i, "vm_pu"] = Vset[b]
    if Vset and int(net.ext_grid.bus[0]) in Vset: net.ext_grid.loc[0, "vm_pu"] = Vset[int(net.ext_grid.bus[0])]
    return net, rating, sdev, cf, rd, keep

def build(P, gfl, kt=3.0, sdev=None, f_pll=70.0, Q=None, load_scale=1.0, Psync=None, Vset=None, net_out=False):
    net, rating, sdev, cf, rd, keep = make_net(P, gfl, kt, sdev, Q, load_scale, Psync, Vset)
    n = len(net.bus); g = np.zeros(n); bl = np.zeros(n)
    pp.runpp(net, numba=False, max_iteration=60, init="dc")
    V = net.res_bus.vm_pu.values; th = np.deg2rad(net.res_bus.va_degree.values)
    for _, ld in net.load.iterrows():          # small-signal load admittance frozen at nominal voltage (LOAD_FROZEN)
        vv = 1.0 if LOAD_FROZEN else V[ld.bus]
        g[ld.bus] += ld.p_mw / BASE / vv ** 2; bl[ld.bus] += ld.q_mvar / BASE / vv ** 2
    # full B (reactance-weighted Laplacian + grounded branches)
    B = np.zeros((n, n))
    def add(f, t, X):
        y = 1 / X; B[f, f] += y
        if t is not None: B[t, t] += y; B[f, t] -= y; B[t, f] -= y
    for _, l in net.line.iterrows():
        z = net.bus.vn_kv[l.from_bus] ** 2 / BASE
        add(int(l.from_bus), int(l.to_bus), l.x_ohm_per_km * l.length_km / z / l.parallel)
    for _, t in net.trafo.iterrows():
        zk = t.vk_percent / 100 * BASE / t.sn_mva / t.parallel
        add(int(t.hv_bus), int(t.lv_bus), zk / np.sqrt(1 + EPS ** 2))
    for b in [int(b) for b in net.gen.bus] + [int(b) for b in net.ext_grid.bus]:
        add(b, None, XS_DEV * BASE / rating.get(b, 1000.0))
    gl = g.copy(); cl = np.zeros(n)
    for j in range(n):
        if bl[j] > 0:
            add(j, None, 1.0 / (bl[j] * (1 + EPS ** 2))); gl[j] = g[j] - EPS * bl[j]
        elif bl[j] < 0:
            cl[j] = -bl[j] / w0
    assert gl.min() > -1e-9, gl.min()
    for _, sh in net.shunt[net.shunt.name == "cap"].iterrows(): cl[int(sh.bus)] += -sh.q_mvar / BASE / w0
    el = [i for i in range(n) if i not in keep]
    Br = B[np.ix_(keep, keep)] - B[np.ix_(keep, el)] @ np.linalg.solve(B[np.ix_(el, el)], B[np.ix_(el, keep)])
    Br = 0.5 * (Br + Br.T)
    devs = {}
    for kk, b in enumerate(gfl):
        k = sdev[b] / BASE; Pb = net.res_sgen.p_mw.values[kk] / BASE; Qb = net.res_sgen.q_mvar.values[kk] / BASE
        A, Bd, C, D = G.gfl_local(V[b], Pb / k, Qb / k, f_pll=f_pll)
        Rt = rot(th[b]); devs[b] = (A, Bd @ Rt.T, k * Rt @ C, k * Rt @ D @ Rt.T)
    s = Sys(); s.n, s.keep, s.Br, s.devs, s.V, s.cf, s.rd, s.gfl = n, keep, Br, devs, V, cf, rd, gfl
    s.g = {j: max(gl[j], 0.0) for j in keep}; s.C = {j: CMIN + cl[j] + (cf[j] if j in gfl else 0.0) for j in keep}
    s.vmin, s.vmax = V.min(), V.max(); s.net = net
    return s

def Ydev(s, b, sl):
    """device admittance at kept bus b (2x2 complex): capacitors + conductance + GFL (+ RC damping)"""
    Y = s.C[b] * (sl * I2 + w0 * J) + s.g[b] * I2
    if b in s.devs:
        A, Bd, C, D = s.devs[b]
        Y = Y - (C @ np.linalg.solve(sl * np.eye(len(A)) - A, Bd) + D)
        rc = s.rd[b] * s.cf[b]                                # RC damping branch, removable-singularity-free form
        Y = Y + (I2 - np.linalg.inv(I2 + rc * (sl * I2 + w0 * J))) / s.rd[b]
    return Y.astype(complex)

def Ypas(s, b, sl):
    """passive part of the bus admittance (capacitors, conductance, RC damping): the Theorem 1 reference system"""
    Y = s.C[b] * (sl * I2 + w0 * J) + s.g[b] * I2
    if b in s.devs:
        rc = s.rd[b] * s.cf[b]; Y = Y + (I2 - np.linalg.inv(I2 + rc * (sl * I2 + w0 * J))) / s.rd[b]
    return Y.astype(complex)

def eig(s):
    """ground truth on the SAME (exactly Kron-reduced) network: RL branches from Kron(B), uniform R/X"""
    keep = s.keep; m = len(keep); Br = s.Br
    br = []
    for a in range(m):
        for c in range(a + 1, m):
            if Br[a, c] < -1e-12: br.append((a, c, -1.0 / Br[a, c]))
        yg = Br[a].sum()
        if yg > 1e-12: br.append((a, None, 1.0 / yg))
    dg = [keep.index(b) for b in s.gfl]
    nd = sum(len(s.devs[b][0]) for b in s.gfl)
    N = nd + 2 * m + 2 * len(br) + 2 * len(dg); A = np.zeros((N, N))
    iv = nd; il = iv + 2 * m; idp = il + 2 * len(br)
    V = lambda a: slice(iv + 2 * a, iv + 2 * a + 2)
    Cb = np.array([s.C[b] for b in keep])
    off = 0
    for b in s.gfl:
        a = keep.index(b); Ad, Bd, Cd, Dd = s.devs[b]; sx = slice(off, off + len(Ad))
        A[sx, sx] = Ad; A[sx, V(a)] = Bd; A[V(a), sx] += Cd / Cb[a]; A[V(a), V(a)] += Dd / Cb[a]; off += len(Ad)
    for a, b in enumerate(keep): A[V(a), V(a)] += (-w0 * J * Cb[a] - s.g[b] * I2) / Cb[a]
    for k, (f, t, X) in enumerate(br):
        L = X / w0; R = EPS * X; si = slice(il + 2 * k, il + 2 * k + 2); A[si, si] = (-R * I2 - w0 * L * J) / L
        A[si, V(f)] += I2 / L; A[V(f), si] -= I2 / Cb[f]
        if t is not None: A[si, V(t)] -= I2 / L; A[V(t), si] += I2 / Cb[t]
    for q, b in enumerate(s.gfl):
        a = keep.index(b); sc = slice(idp + 2 * q, idp + 2 * q + 2); rc = s.rd[b] * s.cf[b]
        A[sc, sc] = -w0 * J - I2 / rc; A[sc, V(a)] = I2 / rc
        A[V(a), V(a)] -= I2 / (s.rd[b] * Cb[a]); A[V(a), sc] += I2 / (s.rd[b] * Cb[a])
    return np.linalg.eigvals(A)

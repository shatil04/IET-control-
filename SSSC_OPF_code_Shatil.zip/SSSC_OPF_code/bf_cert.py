"""Centralised exact-homotopy certificate with Bauer-Fike interval bounds (Theorem 2', no multiplier).
Z = Y0^-1 Y1 = I + Y0^-1 Yact.  On [c-h, c+h]:
  ||dY0|| <= h L0 (network + passive part), ||dYact|| <= h La (GFL part)       [Lemma 2]
  ||Y0(w)^-1|| <= r/(1 - r h L0),  r = ||Y0(c)^-1||
  ||Z(w) - Z(c)|| <= r^2 h L0/(1 - r h L0) * (||Yact(c)|| + h La) + r h La  =: eZ
Bauer-Fike: spec Z(w) within cond(T) eZ of spec Z(c).  If cond(T) eZ < min_i dist(lam_i(c), (-inf, 0]) -> no lam on the
negative axis on the whole interval -> Y(jw; alpha) nonsingular for all alpha in [0,1] and w in the interval."""
import numpy as np, dirb39v2 as M2, dirb_cont as K
from dirb39 import Finv
from testbed9 import w0

def parts(s, w):
    F = np.linalg.inv(Finv(1j*w)); Yn = np.kron(s.Br, F); D0 = np.zeros_like(Yn); Da = np.zeros_like(Yn)
    for j, b in enumerate(s.keep):
        yp = M2.Ypas(s, b, 1j*w); D0[2*j:2*j+2, 2*j:2*j+2] = yp; Da[2*j:2*j+2, 2*j:2*j+2] = M2.Ydev(s, b, 1j*w) - yp
    return Yn + D0, Da, F

def distneg(lam):
    return np.where(lam.real >= 0, np.abs(lam), np.abs(lam.imag))

def lips(s, c, h, F):
    nF = np.linalg.norm(F, 2); q = h * nF / w0
    if q >= 1: return np.inf, np.inf
    dF = (nF ** 2 / w0) / (1 - q) ** 2; dp = 0.0; da = 0.0
    for b in s.keep:
        dg, dr = K.dparts(s, b, c, h); dp = max(dp, s.C[b] + dr); da = max(da, dg)
    return np.linalg.norm(s.Br, 2) * dF + dp, da

def bf_interval(s, a, b, stats, depth=0, maxdepth=30):
    """relative bound: Y0(w) = Y0(c)(I + E0), ||E0|| <= e0 = ||Y0^-1 Yn|| q/(1-q) + r h Lp   (network change = Yn(c)(I (x) Q))
    ||Z(w) - Z(c)|| <= (r h La + e0 ||Y0^-1 Ya(c)||) / (1 - e0)"""
    c = 0.5 * (a + b); h = 0.5 * (b - a); stats["evals"] += 1
    F = np.linalg.inv(Finv(1j*c)); Yn = np.kron(s.Br, F); Yp = np.zeros_like(Yn); Ya = np.zeros_like(Yn)
    for j, bb in enumerate(s.keep):
        yp = M2.Ypas(s, bb, 1j*c); Yp[2*j:2*j+2, 2*j:2*j+2] = yp; Ya[2*j:2*j+2, 2*j:2*j+2] = M2.Ydev(s, bb, 1j*c) - yp
    Y0 = Yn + Yp; Y0i = np.linalg.inv(Y0); W = Y0i @ Ya; lam, T = np.linalg.eig(np.eye(len(Y0)) + W)
    dmin = distneg(lam).min()
    stats["dmin"] = min(stats.get("dmin", np.inf), dmin)
    if dmin <= 0: return False, c
    nF = np.linalg.norm(F, 2); q = h * nF / w0
    if q < 1:
        Lp = 0.0; La = 0.0
        for bb in s.keep:
            dg, dr = K.dparts(s, bb, c, h); Lp = max(Lp, s.C[bb] + dr); La = max(La, dg)
        r = np.linalg.norm(Y0i, 2)
        e0 = np.linalg.norm(Y0i @ Yn, 2) * q / (1 - q) + r * h * Lp
        if e0 < 1:
            eZ = (r * h * La + e0 * np.linalg.norm(W, 2)) / (1 - e0)
            if np.linalg.cond(T) * eZ < dmin: return True, None
    if depth >= maxdepth: return False, c
    ok, where = bf_interval(s, a, c, stats, depth + 1, maxdepth)
    return (ok, where) if not ok else bf_interval(s, c, b, stats, depth + 1, maxdepth)

def certify_band(s, f_lo, f_hi, ncell=200):
    stats = {"evals": 0}; grid = np.geomspace(2*np.pi*max(f_lo, 1e-4), 2*np.pi*f_hi, ncell)
    if f_lo == 0: grid = np.concatenate([[0.0], grid])
    for a, b in zip(grid[:-1], grid[1:]):
        ok, where = bf_interval(s, a, b, stats)
        if not ok: return False, where / 2 / np.pi, stats["evals"]
    return True, None, stats["evals"]

if __name__ == "__main__":
    import sys, time
    from dirb39_probe2 import P0, GFL
    s = M2.build({b: 0.8*P0[b] for b in GFL}, GFL)
    for f in [50, 90, 117.5, 121.4, 200, 300]:
        w = 2*np.pi*f; Y0, Ya, F = parts(s, w); Y0i = np.linalg.inv(Y0); lam, T = np.linalg.eig(np.eye(len(Y0)) + Y0i @ Ya)
        r = np.linalg.norm(Y0i, 2); L0, La = lips(s, w, 1e-3, F); nA = np.linalg.norm(Ya, 2); dmin = distneg(lam).min()
        h = dmin / np.linalg.cond(T) / (r * r * L0 * nA + r * La)
        print(f"{f:6.1f} Hz r={r:.2f} L0={L0:.2f} La={La:.2f} |Ya|={nA:.2f} cond(T)={np.linalg.cond(T):.0f} dmin={dmin:.3f} -> width ~{2*h:.2e} rad/s")


def cert_spectral(P, log=print, f_split=300.0, **bk):
    """spectral certificate on [0, inf): Theorem 2' on [0, f_split], identity band + analytic tail above (Section 5.2)"""
    import time, cert_v2 as CV
    t0 = time.time(); s = M2.build(P, CV.GFL, **bk); stats = {"evals": 0}
    grid = np.concatenate([[0.0], np.geomspace(2*np.pi*1e-3, 2*np.pi*f_split, 300)])
    for a, b in zip(grid[:-1], grid[1:]):
        ok, where = bf_interval(s, a, b, stats, maxdepth=26)
        if not ok: return dict(certified=False, reason=f"spectral test fails near {where/2/np.pi:.3f} Hz", s=s, time=time.time()-t0)
    st2 = {"evals": 0}; idb = K.identity_band(s, 2*np.pi*f_split, CV.WT, st2); tail = K.tail_ok(s, CV.WT)
    if idb or not tail > 0: return dict(certified=False, reason=f"identity band/tail", s=s, time=time.time()-t0)
    return dict(certified=True, margin=stats["dmin"], evals=stats["evals"], s=s, time=time.time()-t0)

"""Figure 2 data: cost of accepted AC-OPF iterates at 90% load (eigenvalue-constrained vs certified)."""
import json
rows = []
for method, fn in (("eig", "results/acopf_eig_L90.json"), ("cert", "results/acopf_certeig_s0_L90.json")):
    for k, r in enumerate(json.load(open(fn))): rows.append(dict(step=k, method=method, cost=round(r["cost"])))
json.dump(rows, open("results/fig2_rows.json", "w"), indent=1)
print(len(rows), "rows written to results/fig2_rows.json")

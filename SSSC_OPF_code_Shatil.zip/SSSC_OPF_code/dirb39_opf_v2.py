"""Certify-and-backtrack OPF on IEEE 39-bus, model v2, with the CONTINUOUS-frequency certificate (cert_v2).
Iterate P^t (certified on [0, inf)) with sample multipliers {m(w)}:
  * active frequencies: the 5 sample points with the smallest full-block margin
  * block-preserving shortage of GFL unit j:  eta_j(w, P_j) = -lambda_min Her(m_j (Y_j(P_j) - Y_j(P_j^t)))
    (others at P^t) on a local grid; eta_j(P^t) = 0, so the subproblem matrix at P^t is exactly H(w; P^t)
  * LMI per active w:  N(w) + blkdiag Her(m_k Y_k(P^t)) - blkdiag_{j in GFL}(T_j(w) I) >= delta_t I,
    T_j >= secant epigraph of eta_j;  Schur-reduced onto the GFL rows
  * delta_t = min(delta, v_t / 2);  trust region |P - P^t| <= Delta
  * accept iff AC power flow solves and the continuous certificate holds (re-optimised multipliers, or the previous
    multipliers as a fallback); otherwise Delta /= 2   (Theorem B2)."""
import numpy as np, cvxpy as cp, json, time, sys, warnings; warnings.filterwarnings("ignore")
import dirb39v2 as M2, dirb_cont as K, cert_v2 as CV, fast_sdp as FS
from dirb39 import Finv
from dirb39_probe2 import P0, GFL
from testbed9 import I2

def herm(X): return 0.5 * (X + X.conj().T)

def fallback(P, recs, log):
    """continuous certificate at P with the previous iterate's sample multipliers (no optimisation)"""
    s = M2.build(P, GFL); stats = {"evals": 0}; pts = [(0.0, recs[0])] + [(r[0], r) for r in recs]; new = []
    for w, r in pts[1:]:
        F = np.linalg.inv(Finv(1j * w)); Ys = [M2.Ydev(s, b, 1j * w) for b in s.keep]
        v = FS.verify_block(F, Ys, s.Br, r[2], r[3], [M2.Ypas(s, b, 1j * w) for b in s.keep])
        if not v > 0: return dict(certified=False)
        new.append((w, v, r[2], r[3], r[4]))
    pts = [(0.0, new[0])] + [(r[0], r) for r in new]
    for (a, ra), (b, rb) in zip(pts[:-1], pts[1:]):
        if not any(K.interval(s, a, b, r[2], r[3], stats, maxdepth=16) for r in (ra, rb)): return dict(certified=False)
    if K.identity_band(s, pts[-1][0], CV.WT, stats) or not K.tail_ok(s, CV.WT) > 0: return dict(certified=False)
    log("    fallback (previous multipliers) certificate holds")
    return dict(certified=True, margin=min(FS.verify_H(s, r) for r in new), recs=new, s=s)

def run(P_start=0.6, P_init=None, iters=8, Delta0=150.0, delta=0.005, cost_gfl=5.0, cost_src=30.0, log=print, nact=5):
    P = dict(P_init) if P_init else {b: P_start * P0[b] for b in GFL}; Delta = Delta0
    cr = CV.certify(P, log=log)
    if not cr["certified"]: log(f"start point not certified: {cr['reason']}"); return []
    s, recs, cur = cr["s"], cr["recs"], cr["margin"]
    hist = [dict(P=dict(P), total=sum(P.values()), margin=cur, stable=bool(M2.eig(s).real.max() < 0))]
    log(f"start: GFL {hist[0]['total']:.0f} MW, continuous certificate, margin {cur:.4f}, stable {hist[0]['stable']}")
    for it in range(iters):
        keep = s.keep; n = len(keep); gi = [keep.index(b) for b in GFL]
        hm = [FS.verify_H(s, r) for r in recs]; act = sorted(range(len(recs)), key=lambda i: hm[i])[:nact]
        offs = np.array([-0.3, -0.15, -0.06, -0.02, 0, 0.02, 0.04, 0.07, 0.1, 0.15, 0.22, 0.3])
        PGU = {b: np.array(sorted(set(np.clip(P[b] / P0[b] + offs, 0.1, 1.3)))) for b in GFL}
        Yt = {i: {b: M2.Ydev(s, b, 1j * recs[i][0]) for b in GFL} for i in act}
        curves = {b: np.zeros((len(PGU[b]), len(act))) for b in GFL}
        for b in GFL:
            jj = keep.index(b)
            for r_, fr in enumerate(PGU[b]):
                Pt = dict(P); Pt[b] = fr * P0[b]
                try: sb = M2.build(Pt, GFL)
                except Exception: curves[b][r_, :] = np.inf; continue
                for c, i in enumerate(act):
                    m = recs[i][2][recs[i][3][jj]]
                    curves[b][r_, c] = -np.linalg.eigvalsh(herm(m @ (M2.Ydev(sb, b, 1j * recs[i][0]) - Yt[i][b])))[0]
        dlt = min(delta, cur / 2)
        mats = []
        for c, i in enumerate(act):
            w = recs[i][0]; F = np.linalg.inv(Finv(1j * w)); Ys = [M2.Ydev(s, b, 1j * w) for b in keep]
            _, H = FS.blocks(F, Ys, s.Br, recs[i][2], recs[i][3])
            var_idx = sorted([2*j for j in gi] + [2*j+1 for j in gi] + [2*n+2*j for j in gi] + [2*n+2*j+1 for j in gi])
            fix_idx = [r for r in range(4 * n) if r not in var_idx]
            Mf = H - dlt * np.eye(4 * n)
            A0 = Mf[np.ix_(var_idx, var_idx)]; Cc = Mf[np.ix_(var_idx, fix_idx)]; Dk = Mf[np.ix_(fix_idx, fix_idx)]
            if np.linalg.eigvalsh(Dk)[0] <= 1e-12: raise RuntimeError("fixed block not PD")
            Sred = A0 - Cc @ np.linalg.solve(Dk, Cc.T); mats.append((0.5 * (Sred + Sred.T), var_idx))
        while True:
            x = cp.Variable(len(GFL)); T = cp.Variable((len(act), len(GFL))); cons = []
            Pnow = np.array([P[b] for b in GFL]); Pn = np.array([P0[b] for b in GFL])
            cons += [cp.abs(x - Pnow) <= Delta, x >= 0.1 * Pn, x <= 1.3 * Pn]
            for c in range(len(act)):
                for g, b in enumerate(GFL):
                    cv = curves[b][:, c]; pg = PGU[b] * P0[b]; ok = np.isfinite(cv); pg, cv = pg[ok], cv[ok]
                    p_t = P[b]; eta_t = 0.0                      # eta(P^t) = 0 by construction (block-preserving shortage)
                    for k in range(len(pg) - 1):
                        a = (cv[k + 1] - cv[k]) / (pg[k + 1] - pg[k])
                        if cv[k] + a * (p_t - pg[k]) > eta_t + 1e-12: continue   # keep P^t feasible (Theorem 3(1))
                        cons.append(T[c, g] >= cv[k] + a * (x[g] - pg[k]))
                    cons += [x[g] <= pg.max(), x[g] >= pg.min()]
                Sred, var_idx = mats[c]
                dv = [-T[c, GFL.index(keep[(r % (2 * n)) // 2])] for r in var_idx]
                Mx = Sred + cp.diag(cp.hstack(dv)); cons.append(0.5 * (Mx + Mx.T) >> 0)
            pr = cp.Problem(cp.Minimize((cost_gfl - cost_src) * cp.sum(x)), cons)
            status = None
            for solver in (cp.CLARABEL, cp.SCS):
                try:
                    pr.solve(solver=solver) if solver != cp.SCS else pr.solve(solver=solver, eps=1e-7, max_iters=200000)
                    status = pr.status
                except Exception as e: status = str(e)[:60]
                if x.value is not None and pr.status in ("optimal", "optimal_inaccurate"): break
            if x.value is None: log(f"  iter {it}: subproblem failed at Delta {Delta:.0f} ({status})"); return hist
            Pc = {b: float(x.value[g]) for g, b in enumerate(GFL)}
            if sum(Pc.values()) < sum(P.values()) + 1.0: log(f"  iter {it}: no improving step (fixed point)"); return hist
            try: cr = CV.certify(Pc, log=lambda m: None)
            except Exception as e: cr = dict(certified=False, reason=str(e))
            if not cr["certified"]:
                try: cr = fallback(Pc, recs, log)
                except Exception: cr = dict(certified=False)
            if cr["certified"]:
                P, s, recs, cur = Pc, cr["s"], cr["recs"], cr["margin"]; st = bool(M2.eig(s).real.max() < 0)
                hist.append(dict(P=dict(P), total=sum(P.values()), margin=cur, stable=st))
                log(f"  iter {it}: accepted {hist[-1]['total']:.0f} MW, margin {cur:.4f}, stable {st}, Delta {Delta:.0f}")
                break
            step = max(abs(Pc[b] - P[b]) for b in GFL)
            Delta = min(Delta, step) / 2; log(f"  iter {it}: candidate {sum(Pc.values()):.0f} MW rejected ({cr.get('reason','')}); Delta -> {Delta:.0f}")
            if Delta < 5: log("  trust region collapsed; stop"); return hist
    return hist

if __name__ == "__main__":
    t0 = time.time(); arg = sys.argv[1]
    if arg.endswith(".json"):
        Pi = {int(k): v for k, v in json.load(open(arg))[-1]["P"].items()}; out = arg.replace(".json", "_cont.json")
        h = run(P_init=Pi, iters=12, log=lambda m: print(m, flush=True))
    else:
        ps = float(arg); out = f"opf_v3_start{int(round(ps*100))}.json"; h = run(P_start=ps, iters=20, log=lambda m: print(m, flush=True))
    json.dump(h, open(out, "w"), indent=1, default=float)
    print(f"done in {(time.time()-t0)/60:.0f} min", flush=True)

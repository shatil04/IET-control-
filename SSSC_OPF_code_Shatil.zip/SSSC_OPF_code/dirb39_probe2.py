import numpy as np, warnings; warnings.filterwarnings("ignore")
import pandapower.networks as pn
import dirb39 as M
from testbed9 import w0
net = pn.case39(); GFL = [32, 33, 34, 35, 36]
P0 = {b: float(net.gen.p_mw[net.gen.bus == b].iloc[0]) for b in GFL}
def ctrl_max(ev):
    c = ev[np.abs(np.abs(ev.imag) - w0) > 2.0]; k = np.argmax(c.real); return c[k]
if __name__ == "__main__":
  for fp in [50, 100]:
        for kt in [3, 6, 10]:
            row = []
            for sc in [0.8, 1.0, 1.2]:
                try:
                    s = M.build({b: sc * P0[b] for b in GFL}, GFL, kt=kt, f_pll=fp); e = ctrl_max(M.eig(s))
                    row.append(f"x{sc}:{e.real:7.2f}@{abs(e.imag)/2/np.pi:5.1f}Hz")
                except Exception: row.append(f"x{sc}: pf-fail")
            print(f"f_pll={fp} kt={kt}: " + "  ".join(row))

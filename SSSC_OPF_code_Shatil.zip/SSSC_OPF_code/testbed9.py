"""Ground-truth testbed: WSCC 9-bus, all three generators replaced by droop GFM converters.
Global dq frame at w0, system per-unit (100 MVA). Dynamic network: RL branches, bus shunt capacitance
(half line charging + small extra), loads as parallel R and L (dynamic). Devices: reduced droop GFM
(admittance form, voltage in, delivered current out), linearised at the power-flow operating point
and rotated to the global frame.

Outputs for a sweep of droop gain mp and virtual reactance Xv:
  * closed-loop spectral abscissa (ground truth)
  * centralised passivity margin   min_w lambda_min He(Y_net(jw) - Y_del(jw))   (>0 => certified)
  * decentralised static margin    min_j [ nu_j + g_j ]                          (>0 => certified)
"""
import numpy as np, pandapower as pp, pandapower.networks as pn, warnings
warnings.filterwarnings("ignore")
J = np.array([[0., -1.], [1., 0.]]); I2 = np.eye(2); w0 = 2 * np.pi * 50
def rot(t): return np.array([[np.cos(t), -np.sin(t)], [np.sin(t), np.cos(t)]])

def gfm_local(V, P, Q, Rv, Xv, mp, mq, fc):
    """Admittance-form droop GFM at local frame where v0=[V,0]. Returns A,B,C,D (input v, output delivered i)."""
    mpr, tau = mp * w0, 1 / (2 * np.pi * fc)
    Zv = Rv * I2 + Xv * J; Yv = np.linalg.inv(Zv)
    v0 = np.array([V, 0.]); i0 = np.array([P / V, -Q / V]); e0 = v0 + Zv @ i0
    E0 = np.linalg.norm(e0); d0 = np.arctan2(e0[1], e0[0]); x0 = np.array([d0, P, Q])
    def cur(x, v):
        E = E0 - mq * (x[2] - Q); e = E * np.array([np.cos(x[0]), np.sin(x[0])]); return Yv @ (e - v)
    def f(x, v):
        i = cur(x, v)
        return np.array([-mpr * (x[1] - P), (-x[1] + v @ i) / tau, (-x[2] - (J @ v) @ i) / tau])
    h = 1e-7
    def jac(fun, a, b, wx):
        base = fun(a, b) if wx else fun(b, a); M = np.zeros((len(base), len(a)))
        for k in range(len(a)):
            da = np.zeros(len(a)); da[k] = h
            M[:, k] = ((fun(a + da, b) if wx else fun(b, a + da)) - base) / h
        return M
    return jac(f, x0, v0, True), jac(f, v0, x0, False), jac(cur, x0, v0, True), jac(cur, v0, x0, False)

def build(mp=0.05, Xv_dev=0.1, Rv_dev=0.05, mq=0.05, fc=5.0, Sdev=250., load_scale=1.0):
    net = pn.case9(); net.load.p_mw *= load_scale; net.load.q_mvar *= load_scale
    for b in net.bus.index: pp.create_shunt(net, b, q_mvar=-1e-4 * net.sn_mva, p_mw=0.0)  # matches extra C below
    pp.runpp(net, numba=False)
    base = net.sn_mva; n = len(net.bus)
    V = net.res_bus.vm_pu.values; th = np.deg2rad(net.res_bus.va_degree.values)
    # branches (R,L in pu; L = X/w0), shunt C per bus
    br, Cb = [], np.full(n, 1e-4 / w0)
    for _, l in net.line.iterrows():
        z = net.bus.vn_kv[l.from_bus] ** 2 / base
        R = l.r_ohm_per_km * l.length_km / z; X = l.x_ohm_per_km * l.length_km / z
        Bsh = 2 * np.pi * net.f_hz * l.c_nf_per_km * 1e-9 * l.length_km * z
        br.append((l.from_bus, l.to_bus, R, X / w0)); Cb[l.from_bus] += Bsh / 2 / w0; Cb[l.to_bus] += Bsh / 2 / w0
    for _, t in net.trafo.iterrows():
        zk = t.vk_percent / 100 * base / t.sn_mva; r = t.vkr_percent / 100 * base / t.sn_mva
        br.append((t.hv_bus, t.lv_bus, r, np.sqrt(zk ** 2 - r ** 2) / w0))
    # loads: parallel G and L
    g = np.zeros(n); bl = np.zeros(n)
    for _, ld in net.load.iterrows():
        g[ld.bus] += ld.p_mw / base / V[ld.bus] ** 2; bl[ld.bus] += ld.q_mvar / base / V[ld.bus] ** 2
    lb = [j for j in range(n) if bl[j] > 0]
    m = len(br); Bi = np.zeros((n, m))
    for k, (f, t, *_) in enumerate(br): Bi[f, k] = 1; Bi[t, k] = -1
    # generator buses and dispatch (gen + ext_grid)
    gens = [(int(r.bus), r.p_mw, r.q_mvar) for r, (_, rr) in zip(net.res_ext_grid.itertuples(), net.ext_grid.iterrows()) for r in [type("x", (), dict(bus=rr.bus, p_mw=net.res_ext_grid.p_mw[_], q_mvar=net.res_ext_grid.q_mvar[_]))]]
    gens += [(int(net.gen.bus[i]), net.res_gen.p_mw[i], net.res_gen.q_mvar[i]) for i in net.gen.index]
    k = Sdev / base
    devs = []
    for (b, P, Q) in gens:
        A, Bd, C, D = gfm_local(V[b], P / base / k, Q / base / k, Rv_dev, Xv_dev, mp, mq, fc)
        Rt = rot(th[b]); devs.append((b, A, Bd @ Rt.T, k * Rt @ C, k * Rt @ D @ Rt.T))
    return dict(n=n, br=br, Cb=Cb, g=g, bl=bl, lb=lb, Bi=Bi, devs=devs, V=V)

def Ynet(sys, s):
    n = sys["n"]; Y = np.zeros((2 * n, 2 * n), complex)
    for k, (f, t, R, L) in enumerate(sys["br"]):
        y = np.linalg.inv((s * L + R) * I2 + w0 * L * J)
        for a, b, sg in [(f, f, 1), (t, t, 1), (f, t, -1), (t, f, -1)]:
            Y[2*a:2*a+2, 2*b:2*b+2] += sg * y
    for j in range(n):
        Y[2*j:2*j+2, 2*j:2*j+2] += sys["Cb"][j] * (s * I2 + w0 * J) + sys["g"][j] * I2
        if sys["bl"][j] > 0:
            Ll = 1 / (w0 * sys["bl"][j]); Y[2*j:2*j+2, 2*j:2*j+2] += np.linalg.inv(s * Ll * I2 + w0 * Ll * J)
    return Y

def Ydel(sys, s):
    n = sys["n"]; Y = np.zeros((2 * n, 2 * n), complex)
    for (b, A, B, C, D) in sys["devs"]:
        Y[2*b:2*b+2, 2*b:2*b+2] = C @ np.linalg.solve(s * np.eye(len(A)) - A, B) + D
    return Y

def closed_loop(sys):
    """Full state space; states: device x, bus v, branch i, load-inductor i."""
    n, br, lb = sys["n"], sys["br"], sys["lb"]; m = len(br)
    nd = sum(len(d[1]) for d in sys["devs"]); N = nd + 2 * n + 2 * m + 2 * len(lb)
    A = np.zeros((N, N)); iv = nd; ii = nd + 2 * n; il = ii + 2 * m
    def V(j): return slice(iv + 2*j, iv + 2*j + 2)
    off = 0
    for (b, Ad, Bd, Cd, Dd) in sys["devs"]:
        sx = slice(off, off + len(Ad)); A[sx, sx] = Ad; A[sx, V(b)] = Bd
        cb = sys["Cb"][b]; A[V(b), sx] += Cd / cb; A[V(b), V(b)] += Dd / cb; off += len(Ad)
    for j in range(n):
        cb = sys["Cb"][j]; A[V(j), V(j)] += (-w0 * J * cb - sys["g"][j] * I2) / cb
    for k, (f, t, R, L) in enumerate(br):
        si = slice(ii + 2*k, ii + 2*k + 2)
        A[si, si] = (-R * I2 - w0 * L * J) / L; A[si, V(f)] += I2 / L; A[si, V(t)] -= I2 / L
        A[V(f), si] -= I2 / sys["Cb"][f]; A[V(t), si] += I2 / sys["Cb"][t]
    for q, j in enumerate(lb):
        Ll = 1 / (w0 * sys["bl"][j]); sl = slice(il + 2*q, il + 2*q + 2)
        A[sl, sl] = -w0 * J; A[sl, V(j)] = I2 / Ll; A[V(j), sl] -= I2 / sys["Cb"][j]
    return np.linalg.eigvals(A)

def margins(sys, ws=np.logspace(-2, 3.5, 600) * 2 * np.pi):
    cen = min(0.5 * np.linalg.eigvalsh((M := Ynet(sys, 1j*w) - Ydel(sys, 1j*w)) + M.conj().T).min() for w in ws)
    dec = []
    for (b, A, B, C, D) in sys["devs"]:
        nu = min(0.5 * np.linalg.eigvalsh((Y := -(C @ np.linalg.solve(1j*w*np.eye(len(A)) - A, B) + D)) + Y.conj().T).min() for w in ws)
        dec.append(nu + sys["g"][b])
    return cen, min(dec)

if __name__ == "__main__":
    print(" mp    Xv(dev pu)  max Re(eig)   damping-min   central margin   decentral margin")
    for mp in [0.02, 0.05, 0.1]:
        for Xv in [0.05, 0.1, 0.3]:
            s = build(mp=mp, Xv_dev=Xv); ev = closed_loop(s)
            k0 = np.argmin(np.abs(ev)); rot0 = ev[k0]; ev = np.delete(ev, k0)   # rotation (gauge) mode
            osc = ev[np.abs(ev.imag) > 1e-3]; zeta = (-osc.real / np.abs(osc)).min() if len(osc) else np.nan
            c, d = margins(s)
            print(f"{mp:4.2f}   {Xv:5.2f}  rot={abs(rot0):.1e}  {ev.real.max():10.4f}   {zeta:10.4f}    {c:12.4f}    {d:12.4f}")

import numpy as np, dirb39v2 as M2
from consv_diag import mats
from dirb39_probe2 import P0, GFL
s = M2.build({b: 0.85*P0[b] for b in GFL}, GFL)
best = (9, None)
for f in np.linspace(60, 200, 28001):
    Y0, Y1 = mats(s, 2*np.pi*f)[3:]; ev = np.linalg.eigvals(np.linalg.solve(Y0, Y1))
    a = np.pi - np.abs(np.angle(ev)); k = np.argmin(a)
    if a[k] < best[0]: best = (a[k], f, ev[k])
print("min angle margin", best)
# alpha-continuation: smallest singular value of Y(jw; alpha) on a grid
mn = (9, None)
for f in np.linspace(100, 140, 4001):
    Y0, Y1 = mats(s, 2*np.pi*f)[3:]
    for al in np.linspace(0, 1, 51):
        sv = np.linalg.svd((1-al)*Y0 + al*Y1, compute_uv=False); r = sv[-1]/sv[0]
        if r < mn[0]: mn = (r, f, al)
print("min sigma ratio", mn)

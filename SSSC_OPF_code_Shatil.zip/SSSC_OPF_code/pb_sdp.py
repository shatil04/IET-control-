import numpy as np, time, scipy.sparse as sp, clarabel, resource, dirb39v2 as M2, fast_sdp as FS
from consv_diag import mats
from dirb39_probe2 import P0, GFL
s = M2.build({b: 0.8*P0[b] for b in GFL}, GFL); n = len(s.keep)
w = 2*np.pi*121.414; F, Ys, Yp, _, _ = mats(s, w); E = FS.E
def coeffs(Yb):
    C = []
    for g in range(n):
        R = np.zeros((n, n)); R[g, :] = s.Br[g, :]
        for part in (1.0, 1j):
            for q in range(4):
                K = np.kron(R, part * E[q] @ F); K[2*g:2*g+2, 2*g:2*g+2] += part * E[q] @ Yb[g]; C.append(FS.realH(K))
    return C
for label, Yb in [("H only", Ys), ("P0 only", Yp)]:
    t0 = time.time(); C = coeffs(Yb); k = 4*n; nv = len(C) + 1
    A1 = np.zeros((k*(k+1)//2, nv))
    for i, Ci in enumerate(C): A1[:, i] = -FS.svec(Ci)
    A1[:, -1] = FS.svec(np.eye(k)); rows = [sp.csc_matrix(A1)]; bs = [np.zeros(k*(k+1)//2)]; cones = [clarabel.PSDTriangleConeT(k)]
    for g in range(n):
        A = np.zeros((9, nv)); bb = np.zeros(9); bb[0] = 1
        for q in range(4): A[1+q, 8*g+q] = -1; A[5+q, 8*g+4+q] = -1
        rows.append(sp.csc_matrix(A)); bs.append(bb); cones.append(clarabel.SecondOrderConeT(9))
    qv = np.zeros(nv); qv[-1] = -1; st = clarabel.DefaultSettings(); st.verbose = False; st.chordal_decomposition_enable = False
    sol = clarabel.DefaultSolver(sp.csc_matrix((nv, nv)), qv, sp.vstack(rows).tocsc(), np.concatenate(bs), cones, st).solve()
    x = np.array(sol.x); ms = [sum((x[8*g+q] + 1j*x[8*g+4+q]) * E[q] for q in range(4)) for g in range(n)]; nm = max(np.linalg.norm(m, 2) for m in ms)
    P, H = FS.blocks(F, Ys, s.Br, [m/nm for m in ms], {j: j for j in range(n)}, Yp)
    print(label, sol.status, "t", round(sol.x[-1], 5), "| lam_min P0", round(np.linalg.eigvalsh(P)[0], 4), "H", round(np.linalg.eigvalsh(H)[0], 4), f"{time.time()-t0:.0f}s", resource.getrusage(resource.RUSAGE_SELF).ru_maxrss//1024, "MB", flush=True)

"""Publication figures (vector PDF + EPS) for IET CTA: Fig. 1 homotopy crossing, Fig. 2 AC-OPF convergence."""
import json, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1.inset_locator import inset_axes, mark_inset
plt.rcParams.update({"font.family": "serif", "font.size": 8, "axes.linewidth": 0.6, "lines.linewidth": 1.2,
                     "xtick.major.width": 0.6, "ytick.major.width": 0.6, "legend.frameon": False, "pdf.fonttype": 42, "ps.fonttype": 42})
import os; os.makedirs("figs", exist_ok=True)
W = 3.5  # single-column width, inches
d = json.load(open("results/fig1_data.json"))
fig, ax = plt.subplots(figsize=(W, 2.5))
for key, ls, col, lab in (("0.8", "--", "0.45", "80% output (stable)"), ("0.85", "-", "k", "85% output (unstable)")):
    f, v = np.array(d[key]["f"]), np.maximum(np.array(d[key]["d"]), 1e-6); ax.semilogy(f, v, ls=ls, color=col, label=lab)
fs, ds = np.array(d["0.85"]["fs"]), np.array(d["0.85"]["ds"])
ax.semilogy(fs, ds, "o", ms=3, mfc="white", mec="k", mew=0.6, label="85%: samples of a 4,000-point grid")
z = d["0.85_zoom"]; fz, dz = np.array(z["f"]), np.array(z["d"]); i0 = int(np.argmin(dz)); fc = fz[i0]
ax.axvline(fc, color="0.3", lw=0.6, ls=":")
ax.set_xlabel("Frequency (Hz)"); ax.set_ylabel(r"dist$(\mathrm{spec}\,Y_0^{-1}Y_1,\;(-\infty,0])$")
ax.set_xlim(f.min(), f.max()); ax.set_ylim(1e-5, 0.3); ax.legend(loc="lower left", fontsize=6.5, handlelength=1.8)
ia = inset_axes(ax, width="100%", height="100%", bbox_to_anchor=(0.69, 0.25, 0.29, 0.3), bbox_transform=ax.transAxes, borderpad=0)
ia.plot(fz, dz * 1e3, color="k", lw=1); ia.axhline(0, color="0.5", lw=0.5)
ia.set_xlim(fz.min(), fz.max()); ia.set_xticks([117.51, 117.55]); ia.set_xticklabels(["117.51", "117.55"]); ia.tick_params(labelsize=5.5)
ia.text(0.5, 0.97, "zoom (×10⁻³)", transform=ia.transAxes, ha="center", va="top", fontsize=5.5)
fig.subplots_adjust(left=0.17, right=0.98, top=0.97, bottom=0.16)
for ext in ("pdf", "eps"): fig.savefig(f"figs/fig1_homotopy_crossing.{ext}")
fig.savefig("figs/fig1_homotopy_crossing.png", dpi=300); print("crossing near", fc)

r = json.load(open("results/fig2_rows.json"))
fig, ax = plt.subplots(figsize=(W, 2.2))
for m, ls, mk, lab in (("eig", "--", "s", "Eigenvalue-constrained (uncertified)"), ("cert", "-", "o", "Certified (eigenvalue-guided steps)")):
    rr = [x for x in r if x["method"] == m]; ax.plot([x["step"] for x in rr], [x["cost"] / 1e3 for x in rr], ls=ls, marker=mk, ms=2.5, color="k" if m == "cert" else "0.45", label=lab)
ax.axhline(109.033, color="0.6", lw=0.6, ls=":"); ax.text(31, 110.2, "plain optimum (unstable): 109.0", ha="right", fontsize=6.5, color="0.35")
ax.set_xlabel("Accepted step"); ax.set_ylabel("Operating cost (k\\$/h)"); ax.legend(loc="upper right", fontsize=6.5)
fig.tight_layout(pad=0.3)
for ext in ("pdf", "eps"): fig.savefig(f"figs/fig2_acopf_convergence.{ext}")
fig.savefig("figs/fig2_acopf_convergence.png", dpi=300)
# graphical abstract image 50 x 60 mm
fig, ax = plt.subplots(figsize=(60 / 25.4, 50 / 25.4))
f, v = np.array(d["0.85"]["f"]), np.maximum(np.array(d["0.85"]["d"]), 1e-6); ax.semilogy(f, v, "k-", lw=1)
ax.semilogy(fs, ds, "o", ms=2.5, mfc="white", mec="k", mew=0.5); ax.axvline(fc, color="0.3", lw=0.6, ls=":")
ax.set_xticks([110, 115, 120, 125]); ax.set_xlabel("Frequency (Hz)", fontsize=7); ax.set_ylabel("Distance to $(-\\infty,0]$", fontsize=7); ax.tick_params(labelsize=6)
ax.set_title("Samples miss the crossing;\ninterval bounds do not", fontsize=7); fig.tight_layout(pad=0.2)
fig.savefig("figs/graphical_abstract.png", dpi=600); fig.savefig("figs/graphical_abstract.pdf")

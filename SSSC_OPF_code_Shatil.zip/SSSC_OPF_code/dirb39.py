"""Direction B on IEEE 39-bus: uniform R/X, GFL units at chosen generator buses, all other generators (and the
external grid) as voltage sources behind a reactance (grounded branches). Certificate = Theorem B1 with the
per-frequency multiplier family; ground truth = full electromagnetic eigenvalues.
Also: certify-and-backtrack sequential OPF (trust region; accept only AC-feasible, certified points)."""
import numpy as np, pandapower as pp, pandapower.networks as pn, cvxpy as cp, warnings, time
warnings.filterwarnings("ignore")
import testbed9_gfl as G
from testbed9 import J, I2, w0, rot

EPS = 0.1; BASE = 100.; CMIN = 1e-4 / w0
XS_DEV = 0.25            # source reactance on its own rating (transient-reactance-like)
PHI = np.deg2rad(np.arange(-80, 81, 10)); BETA = [0.0, 0.25, 0.5, 0.75, 1.0]
WS = np.concatenate([[1e-3], np.logspace(-1, 3.5, 90)]) * 2 * np.pi

class Sys: pass

_QBASE = {}
def qbase():
    if not _QBASE:
        net = pn.case39(); net.line.r_ohm_per_km = EPS * net.line.x_ohm_per_km; net.line.c_nf_per_km = 0.0
        vk = net.trafo.vk_percent.values; net.trafo.vkr_percent = vk * EPS / np.sqrt(1 + EPS ** 2)
        pp.runpp(net, numba=False, init="dc", max_iteration=60)
        _QBASE.update({int(b): float(q) for b, q in zip(net.gen.bus, net.res_gen.q_mvar)})
    return _QBASE

def build(P, gfl, kt=1.0, sdev=None, load_scale=1.0, f_pll=50.0, Q=None):
    """P: dict bus->MW for GFL units. gfl: list of bus indices (generator buses) converted to GFL."""
    net = pn.case39(); net.load.p_mw *= load_scale; net.load.q_mvar *= load_scale
    net.line.r_ohm_per_km = EPS * net.line.x_ohm_per_km; net.line.c_nf_per_km = 0.0
    vk = net.trafo.vk_percent.values; net.trafo.vkr_percent = vk * EPS / np.sqrt(1 + EPS ** 2)
    if "shunt" in net and len(net.shunt): net.shunt.drop(net.shunt.index, inplace=True)
    for b in gfl:                                              # weaken GFL connections
        idx = net.trafo.index[(net.trafo.lv_bus == b) | (net.trafo.hv_bus == b)]
        net.trafo.loc[idx, "vk_percent"] *= kt; net.trafo.loc[idx, "vkr_percent"] *= kt
    rating = {int(net.gen.bus[i]): max(net.gen.p_mw[i] * 1.25, 300.0) for i in net.gen.index}
    sdev = sdev or {b: rating[b] for b in gfl}
    net.gen.drop(net.gen.index[net.gen.bus.isin(gfl)], inplace=True)
    cf = {b: 0.05 * (sdev[b] / BASE) / w0 for b in gfl}; rd = {b: 1.0 / (2 * np.pi * 180 * cf[b]) for b in gfl}
    for b in gfl:
        pp.create_sgen(net, b, p_mw=P[b], q_mvar=(Q or qbase())[b])
        yd = 1 / (rd[b] + 1 / (1j * w0 * cf[b]))
        pp.create_shunt(net, b, p_mw=yd.real * BASE, q_mvar=-(yd.imag + w0 * cf[b]) * BASE)
    for b in net.bus.index: pp.create_shunt(net, b, q_mvar=-w0 * CMIN * BASE, p_mw=0.0)
    pp.runpp(net, numba=False, max_iteration=60, init="dc")
    V = net.res_bus.vm_pu.values; th = np.deg2rad(net.res_bus.va_degree.values); n = len(V)
    lines = []
    for _, l in net.line.iterrows():
        z = net.bus.vn_kv[l.from_bus] ** 2 / BASE
        lines.append((int(l.from_bus), int(l.to_bus), l.x_ohm_per_km * l.length_km / z / l.parallel))
    for _, t in net.trafo.iterrows():
        zk = t.vk_percent / 100 * BASE / t.sn_mva / t.parallel
        lines.append((int(t.hv_bus), int(t.lv_bus), zk / np.sqrt(1 + EPS ** 2)))
    src = [int(b) for b in net.gen.bus] + [int(b) for b in net.ext_grid.bus]
    for b in src:
        Srat = rating.get(b, 1000.0); lines.append((b, None, XS_DEV * BASE / Srat))   # grounded source branch
    g = np.zeros(n); bl = np.zeros(n)
    for _, ld in net.load.iterrows():
        g[ld.bus] += ld.p_mw / BASE / V[ld.bus] ** 2; bl[ld.bus] += ld.q_mvar / BASE / V[ld.bus] ** 2
    devs = {}
    for kk, b in enumerate(gfl):
        k = sdev[b] / BASE; Pb = net.res_sgen.p_mw.values[kk] / BASE; Qb = net.res_sgen.q_mvar.values[kk] / BASE
        A, Bd, C, D = G.gfl_local(V[b], Pb / k, Qb / k, f_pll=f_pll)
        Rt = rot(th[b]); devs[b] = (A, Bd @ Rt.T, k * Rt @ C, k * Rt @ D @ Rt.T)
    s = Sys(); s.n, s.lines, s.g, s.bl, s.devs, s.V, s.cf, s.rd, s.gfl = n, lines, g, bl, devs, V, cf, rd, gfl
    s.vmin, s.vmax = V.min(), V.max(); s.load_mw = net.res_load.p_mw.sum()
    return s

def eig(s):
    n = s.n; dg = list(s.devs); lb = [j for j in range(n) if s.bl[j] > 0]
    nd = sum(len(s.devs[b][0]) for b in dg); m = len(s.lines)
    N = nd + 2 * n + 2 * m + 2 * len(lb) + 2 * len(dg); A = np.zeros((N, N))
    iv = nd; il = iv + 2 * n; iL = il + 2 * m; idp = iL + 2 * len(lb)
    V = lambda b: slice(iv + 2 * b, iv + 2 * b + 2)
    Cb = np.full(n, CMIN);
    for b in dg: Cb[b] += s.cf[b]
    off = 0
    for b in dg:
        Ad, Bd, Cd, Dd = s.devs[b]; sx = slice(off, off + len(Ad))
        A[sx, sx] = Ad; A[sx, V(b)] = Bd; A[V(b), sx] += Cd / Cb[b]; A[V(b), V(b)] += Dd / Cb[b]; off += len(Ad)
    for b in range(n): A[V(b), V(b)] += (-w0 * J * Cb[b] - s.g[b] * I2) / Cb[b]
    for k, (f, t, X) in enumerate(s.lines):
        L = X / w0; R = EPS * X; si = slice(il + 2 * k, il + 2 * k + 2); A[si, si] = (-R * I2 - w0 * L * J) / L
        A[si, V(f)] += I2 / L; A[V(f), si] -= I2 / Cb[f]
        if t is not None: A[si, V(t)] -= I2 / L; A[V(t), si] += I2 / Cb[t]
    for q, b in enumerate(lb):
        Ll = 1 / (w0 * s.bl[b]); sl = slice(iL + 2 * q, iL + 2 * q + 2)
        A[sl, sl] = -w0 * J; A[sl, V(b)] = I2 / Ll; A[V(b), sl] -= I2 / Cb[b]
    for q, b in enumerate(dg):
        sc = slice(idp + 2 * q, idp + 2 * q + 2); rc = s.rd[b] * s.cf[b]
        A[sc, sc] = -w0 * J - I2 / rc; A[sc, V(b)] = I2 / rc
        A[V(b), V(b)] -= I2 / (s.rd[b] * Cb[b]); A[V(b), sc] += I2 / (s.rd[b] * Cb[b])
    return np.linalg.eigvals(A)

def Ydev(s, b, sl):
    Y = (CMIN * (sl * I2 + w0 * J)).astype(complex) + s.g[b] * I2
    if s.bl[b] > 0:
        Ll = 1 / (w0 * s.bl[b]); Y = Y + np.linalg.inv(sl * Ll * I2 + w0 * Ll * J)
    if b in s.devs:
        A, Bd, C, D = s.devs[b]
        Y = Y - (C @ np.linalg.solve(sl * np.eye(len(A)) - A, Bd) + D)
        Y = Y + s.cf[b] * (sl * I2 + w0 * J) + np.linalg.inv(s.rd[b] * I2 + np.linalg.inv(s.cf[b] * (sl * I2 + w0 * J)))
    return Y
Finv = lambda sl: (sl / w0 + EPS) * I2 + J
hmin = lambda M: np.linalg.eigvalsh(0.5 * (M + M.conj().T)).min()
def Bred(s):
    Bm = np.zeros((s.n, s.n))
    for f, t, X in s.lines:
        y = 1 / X; Bm[f, f] += y
        if t is not None: Bm[t, t] += y; Bm[f, t] -= y; Bm[t, f] -= y
    return Bm

def schedule(s):
    """Best common multiplier per frequency at this operating point; returns schedule and worst margin."""
    Br = Bred(s); sch = []; worst = np.inf
    for w in WS:
        sl = 1j * w; F = np.linalg.inv(Finv(sl)); Fi = Finv(sl); Ys = [Ydev(s, b, sl) for b in range(s.n)]
        best = (-np.inf, None)
        for be in BETA:
            base = (1 - be) * Fi + be * I2; netf = (1 - be) * I2 + be * F
            for ph in PHI:
                e = np.exp(1j * ph); gg = hmin(e * netf)
                if gg <= 0: continue
                nu = np.array([hmin(e * (Y @ base)) for Y in Ys]) / gg
                mm = np.linalg.eigvalsh(Br + np.diag(nu)).min()
                if mm > best[0]: best = (mm, (ph, be, gg))
        sch.append(best[1]); worst = min(worst, best[0])
    return sch, worst

def eta_bus(s, sch, b):
    out = np.zeros(len(WS))
    for i, (w, (ph, be, gg)) in enumerate(zip(WS, sch)):
        sl = 1j * w; e = np.exp(1j * ph)
        out[i] = -hmin(e * (Ydev(s, b, sl) @ ((1 - be) * Finv(sl) + be * I2))) / gg
    return out

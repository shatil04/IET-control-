import sys, json, numpy as np, acopf as A
cap = float(sys.argv[1]); x0 = A.x_from(0.6)
h = A.run(x0, stability=False, phase1=True, gfl_cap=cap, iters=40, log=lambda m: None, tag="[cap]")
print(f"cap {cap:.0f} MW: final violation {h[-1]['viol']:.4f}, GFL {h[-1]['gfl']:.0f} MW, iterations {len(h)-1}", flush=True)
json.dump(h, open(f"capfeas_{int(cap)}.json","w"), default=float)

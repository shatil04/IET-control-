"""Per-frequency comparison on a 0-300 Hz grid at one operating point:
 block-diagonal (decentralised; fast_sdp.step_block, best of common/hybrid) vs area-wise (k areas) vs exact spectral.
usage: LOAD_SCALE=.. python3 area_probe.py point.json k1 k2 ...   (k = number of areas; k = 1 is the full multiplier)"""
import sys, json, time, numpy as np, os
import acopf as A, dirb39v2 as M2, fast_sdp as FS, area_mult as AM
from dirb39 import WS, Finv

x = np.array(json.load(open(sys.argv[1]))[-1]['x']); Pg, kw = A.bk(x); s = M2.build(Pg, A.GFL, **kw)
ks = [int(a) for a in sys.argv[2:]]
labs = {k: (np.zeros(len(s.keep), int) if k == 1 else AM.areas_spectral(s.Br, k)) for k in ks}
for k in ks: print(f"k={k} areas:", [[s.keep[j] + 1 for j in np.where(labs[k] == a)[0]] for a in range(k)], flush=True)
special = [s.keep.index(b) for b in s.gfl]
ws = [w for w in WS if 0 < w <= 2 * np.pi * 300 * 1.0001]
rows = []; t0 = time.time()
for w in ws:
    Y0, Y1 = AM.mats(s, w); F = np.linalg.inv(Finv(1j * w))
    Ys = [M2.Ydev(s, b, 1j * w) for b in s.keep]; Yp = [M2.Ypas(s, b, 1j * w) for b in s.keep]
    vb, _, mode = FS.step_block(F, Ys, s.Br, special, Ypas=Yp)
    r = dict(f=w / 2 / np.pi, block=float(vb), spec=AM.spectral_ok(Y0, Y1))
    for k in ks:
        if r['block'] > FS.TOL: r[f"area{k}"] = r['block']; continue        # block-diagonal is a special case of area-wise
        t, M = AM.solve_area_scaled(Y0, Y1, labs[k]); r[f"area{k}"] = AM.verify_scaled(Y0, Y1, M) if M is not None else -np.inf
    rows.append(r)
    print(f"{r['f']:8.2f} Hz  block {r['block']:+.2e}  " + "  ".join(f"area{k} {r[f'area{k}']:+.2e}" for k in ks) + f"  spec {r['spec']:.2e} [{time.time()-t0:.0f}s]", flush=True)
out = os.path.basename(sys.argv[1]).replace('.json', '') + "_areaprobe.json"
json.dump(dict(areas={k: labs[k].tolist() for k in ks}, keep=s.keep, rows=rows), open(out, "w"), indent=1)
fails = lambda key: sum(1 for r in rows if not r[key] > 0)
print("frequencies without certificate:", "block", fails("block"), " ".join(f"area{k} {fails(f'area{k}')}" for k in ks), "spec", sum(1 for r in rows if r['spec'] <= 0))

# Certified small-signal stability constraints in optimal power flow — code and data

Code and results for the paper

> A. H. M. Shatil, "Certified Small-Signal Stability Constraints in Optimal Power Flow for Grid-Following-Dominated Networks," submitted to *IET Control Theory & Applications*, 2026.

Everything runs on the IEEE 39-bus system (pandapower `case39`) with five grid-following units at buses 33–37 (MATPOWER numbering). No external data is needed.

## Installation

```bash
python3 -m pip install -r requirements.txt
```

Tested with Python 3.13 on Linux, on 2 CPU cores. Run all commands from this folder.

## Reproducing the paper

| Script | Paper item | Run time (2 cores) |
|---|---|---|
| `scripts/01_certificate_scan.sh` | Section 7.2: certificate against ground truth, tiered certificate | ~30 min |
| `scripts/02_figure1_data.sh` | Figure 1 data: the single crossing at 117.5305–117.5310 Hz | a few minutes |
| `scripts/03_dc_opf.sh` | Section 7.3: DC-cost certified OPF | ~3.5 h |
| `scripts/04_acopf_90.sh` | Section 7.4, 90 % load: plain, eigenvalue baseline, structured, spectral and certified OPF | several hours |
| `scripts/05_acopf_100.sh` | Section 7.4, 100 % load | several hours |
| `scripts/06_damping_margin.sh` | Section 5.5 and Section 7.4: Theorem 4 validation and certified damping margins | ~1 h |
| `scripts/07_area_multipliers.sh` | Section 5.6: area-wise multipliers (Proposition 4) | ~1–1.5 h |
| `scripts/08_figures.sh` | Figures 1–2 and graphical abstract, from `results/` | seconds |

New result files are written to this folder and logs to `logs/`. The files used in the paper are in `results/`, so `08_figures.sh` and the checks in `06_damping_margin.sh` run without first repeating the long optimisations.

## Main modules

| File | Content |
|---|---|
| `dirb39v2.py` | IEEE 39-bus model: uniform R/X network, exact Kron reduction, load inductors, line charging as capacitor banks, grid-following unit admittances `Ydev`, passive parts `Ypas`, full-model eigenvalues `eig` |
| `dirb39.py`, `testbed9.py`, `testbed9_gfl.py`, `dirb39_probe2.py` | Network factor F_ε, frequency grid, unit model and base data |
| `fast_sdp.py` | Multiplier search: common (scalar SDP in conic form, Clarabel) and hybrid (first-order ascent); exact block verification (Theorem 1, Corollary 1) |
| `dirb_cont.py` | Interval bounds for structured multipliers (Lemma 2, Theorem 2), identity band and analytic tail |
| `bf_cert.py` | Continuous spectral test with Bauer–Fike intervals and the relative network bound (Theorem 2′) |
| `cert_v2.py` | Tiered continuous certificate (Section 5.4) |
| `bf_shift.py` | Certified damping margin on the shifted line (Theorem 4) |
| `area_mult.py`, `area_probe.py` | Area-wise multipliers and the per-frequency comparison (Proposition 4) |
| `dirb39_opf_v2.py` | Certify-and-backtrack OPF, DC-cost variant (Section 7.3) |
| `acopf.py` | Sequential AC-OPF with certificate acceptance (Section 6, Theorem 3). Modes: `plain`, `eig`, `stab`, `stab3`, `certeig`. Environment variables: `LOAD_SCALE`, `RHO`, `SPECTRAL`, `EIGM`, `SIGMA`, `CAP` |
| `capfeas.py` | Feasible starting point with capped grid-following output |
| `cert_pt.py`, `cert_shift_pt.py` | Certify a stored AC-OPF point (spectral certificate; damping margin σ) |
| `consv_diag.py`, `exact_scan.py`, `exact_fine.py`, `full_mult.py`, `pb_sdp.py` | Diagnostics: exact homotopy scans, full and per-bus multipliers |
| `fig1_data.py`, `fig1_refine.py`, `make_fig2_data.py`, `make_figs.py` | Figure data and plotting |

## Results (`results/`)

| File | Content |
|---|---|
| `cert_tiered_scan.json`, `cert_v2_scan.json` | Uniform-scaling certificates (Section 7.2) |
| `opf_v3_start60.json`, `opf_v3_start75.json` | DC-cost certified OPF iterates |
| `acopf_plain_60_L90.json`, `acopf_plain_80.json` | Plain AC-OPF at 90 % and 100 % load |
| `acopf_eig_L90.json`, `acopf_eig_L100.json` | Eigenvalue-constrained baseline |
| `acopf_cert_final_L90.json` | Structured-certificate optimum at 90 % load |
| `acopf_stab3_L90.json`, `acopf_stab3_phase1_L90.json` | Spectral step model at 90 % load, and its certified feasible start |
| `acopf_certeig_s0_L90.json`, `acopf_certeig_s0_L100.json` | Certified eigenvalue-guided OPF (σ = 0) |
| `acopf_certeig_s1_final_L90.json` | Certified OPF with σ = 1 s⁻¹ (stopped at 140,567 $/h) |
| `capfeas_2300.json`, `start_L90_feasible.json` | Starting points at 100 % and 90 % load |
| `acopf_eig_L90_areaprobe.json` | Area-wise multiplier comparison |
| `fig1_data.json`, `fig2_rows.json` | Figure data |

Each AC-OPF file is a list of accepted iterates with the decision vector `x` (19 entries: four synchronous P, five grid-following P and Q, five voltage set-points), cost ($/h), constraint violation, total grid-following output (MW), certificate margin and the full-model stability flag.

## Notes

- Timings depend on the BLAS library; the scripts fix one thread per process, as in the paper.
- The sequential AC-OPF uses finite differences of the pandapower power flow. Different library versions can change the last digits of the iterates, though the certificates themselves are exact.

## Licence

MIT (see `LICENSE`).

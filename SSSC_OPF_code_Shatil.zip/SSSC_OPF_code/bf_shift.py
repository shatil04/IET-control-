"""Damping-margin certificate: spectral homotopy test on the shifted line s = -sigma + j w (Theorem 4).
Conditions:
 (i)  passive reference Sigma_0 has all modes left of -sigma (finite eigenvalue check; Sigma_0 independent of dispatch
      when loads are frozen, but checked per point anyway);
 (ii) Z(s) = Y0(s)^-1 Y1(s) has no eigenvalue on (-inf, 0] for s = -sigma + j w, w in [0, w_T]  (Bauer-Fike intervals);
 (iii) tail w >= w_T:  ||Y0(s)^-1|| ||Ya(s)|| < 1  (then spec Z within distance < 1 of 1), via monotone bounds.
Then every closed-loop eigenvalue has real part < -sigma."""
import numpy as np, dirb39v2 as M2, dirb_cont as K
from dirb39 import Finv
from testbed9 import w0, J, I2

def parts(s, sl):
    F = np.linalg.inv(Finv(sl)); Yn = np.kron(s.Br, F); Yp = np.zeros_like(Yn); Ya = np.zeros_like(Yn)
    for j, b in enumerate(s.keep):
        yp = M2.Ypas(s, b, sl); Yp[2*j:2*j+2, 2*j:2*j+2] = yp; Ya[2*j:2*j+2, 2*j:2*j+2] = M2.Ydev(s, b, sl) - yp
    return Yn, Yp, Ya, F

def distneg(lam): return np.where(lam.real >= 0, np.abs(lam), np.abs(lam.imag))

def dparts(s, b, sl, h):
    if b not in s.devs: return 0.0, 0.0
    A, Bd, C, D = K.balanced(s, b); R = np.linalg.inv(sl * np.eye(len(A)) - A); nR = np.linalg.norm(R, 2)
    dg = np.inf if h * nR >= 1 else np.linalg.norm(C @ R, 2) * np.linalg.norm(R @ Bd, 2) / (1 - h * nR) ** 2
    rc = s.rd[b] * s.cf[b]; Kk = np.linalg.inv(I2 + rc * (sl * I2 + w0 * J)); nK = np.linalg.norm(Kk, 2)
    dr = np.inf if h * rc * nK >= 1 else s.cf[b] * nK ** 2 / (1 - h * rc * nK) ** 2
    return dg, dr

def interval(s, sigma, a, b, stats, depth=0, maxdepth=28):
    c = 0.5 * (a + b); h = 0.5 * (b - a); sl = -sigma + 1j * c; stats["evals"] += 1
    Yn, Yp, Ya, F = parts(s, sl); Y0 = Yn + Yp; Y0i = np.linalg.inv(Y0); W = Y0i @ Ya
    lam, T = np.linalg.eig(np.eye(len(Y0)) + W); dmin = distneg(lam).min()
    stats["dmin"] = min(stats.get("dmin", np.inf), dmin)
    if dmin <= 0: return False, c
    q = h * np.linalg.norm(F, 2) / w0
    if q < 1:
        Lp = La = 0.0
        for bb in s.keep:
            dg, dr = dparts(s, bb, sl, h); Lp = max(Lp, s.C[bb] + dr); La = max(La, dg)
        r = np.linalg.norm(Y0i, 2); e0 = np.linalg.norm(Y0i @ Yn, 2) * q / (1 - q) + r * h * Lp
        if e0 < 1:
            eZ = (r * h * La + e0 * np.linalg.norm(W, 2)) / (1 - e0)
            if np.linalg.cond(T) * eZ < dmin: return True, None
    if depth >= maxdepth: return False, c
    ok, where = interval(s, sigma, a, c, stats, depth + 1, maxdepth)
    return (ok, where) if not ok else interval(s, sigma, c, b, stats, depth + 1, maxdepth)

def tail_ok(s, sigma, wT):
    """|s| >= wT on the shifted line. Nonzero eigenvalues of Y0^-1 Ya are those of Ya_gg S_g^-1 (S_g = Schur complement of
    Y0 onto the unit buses). If Her(Y0) >= blkdiag(D_g, 0) then Her(S_g) >= D_g (accretive Schur complement), with
    D_g,j = (1/rd)(1 - ||K_j||) - sigma C_j (RC branch + capacitor at the unit bus). Requires g_j - sigma C_j >= 0 at the
    other buses and sigma < eps*w0 (network Hermitian part >= 0). Then |eig(Z) - 1| <= ||Ya_gg|| / min_j D_g,j < 1."""
    from dirb39 import EPS
    if sigma >= EPS * w0: return False, np.inf
    for b in s.keep:
        if b not in s.devs and s.g[b] - sigma * s.C[b] < 0: return False, np.inf
    na = 0.0; dmin = np.inf
    for b in s.devs:
        A, Bd, C, D = K.balanced(s, b); nA = np.linalg.norm(A, 2)
        if wT <= nA: return False, np.inf
        na = max(na, np.linalg.norm(C, 2) * np.linalg.norm(Bd, 2) / (wT - nA) + np.linalg.norm(D, 2))
        rc = s.rd[b] * s.cf[b]; nK = 1 / np.sqrt((1 - rc * sigma) ** 2 + (rc * max(wT - w0, 0)) ** 2)
        dmin = min(dmin, (1 / s.rd[b]) * (1 - nK) - sigma * s.C[b] + s.g[b])
    if dmin <= 0: return False, np.inf
    return na / dmin < 1, na / dmin

def tail_sv(s, sigma, wT):
    """singular-value tail: ||Z - I|| <= ||Ya|| / (min_j smin(Ypas_j) - ||Br|| ||F||), all terms monotone in w >= wT.
    smin(Ypas_j) >= max(C_j (w - w0) - |g_j - sigma C_j|, g_j - sigma C_j) - ||Y_RC,j||,  ||Y_RC|| <= 2/rd."""
    from dirb39 import EPS
    na = 0.0
    for b in s.devs:
        A, Bd, C, D = K.balanced(s, b); nA = np.linalg.norm(A, 2)
        if wT <= nA: return False, np.inf
        na = max(na, np.linalg.norm(C, 2) * np.linalg.norm(Bd, 2) / (wT - nA) + np.linalg.norm(D, 2))
    smin = np.inf
    for b in s.keep:
        gs = s.g[b] - sigma * s.C[b]; v = max(s.C[b] * (wT - w0) - abs(gs), gs)
        if b in s.devs: v -= 2 / s.rd[b]
        smin = min(smin, v)
    nF = 1 / np.sqrt((EPS - sigma / w0) ** 2 + (wT / w0 - 1) ** 2)
    den = smin - np.linalg.norm(s.Br, 2) * nF
    if den <= 0: return False, np.inf
    return na / den < 1, na / den

def passive_abscissa(s):
    """spectral abscissa of the passive reference Sigma_0 (current sources removed)"""
    import copy
    s0 = copy.copy(s); s0.devs = {b: (A, Bd, 0 * C, 0 * D) for b, (A, Bd, C, D) in s.devs.items()}
    ev = M2.eig(s0)
    # device-internal modes (A_j) are decoupled at alpha = 0 and do not belong to Sigma_0's network; they are stable anyway
    return float(ev.real.max())

def certify_shift(s, sigma, f_hi=None, ncell=400):
    import time
    t0 = time.time(); pa = passive_abscissa(s)
    if not pa < -sigma: return dict(certified=False, reason=f"passive reference abscissa {pa:.2f}", time=time.time()-t0)
    wT = 2 * np.pi * 1e3
    while True:
        ok, ratio = tail_ok(s, sigma, wT)
        if not ok: ok, ratio = tail_sv(s, sigma, wT)
        if ok: break
        wT *= 2
        if wT > 1e9: return dict(certified=False, reason="tail", time=time.time()-t0)
    stats = {"evals": 0}; grid = np.concatenate([[0.0], np.geomspace(2*np.pi*1e-3, wT, ncell)])
    for a, b in zip(grid[:-1], grid[1:]):
        ok, where = interval(s, sigma, a, b, stats)
        if not ok: return dict(certified=False, reason=f"fails near {where/2/np.pi:.3f} Hz", time=time.time()-t0, evals=stats["evals"])
    return dict(certified=True, dmin=stats["dmin"], evals=stats["evals"], wT=wT, passive=pa, time=time.time()-t0)

if __name__ == "__main__":
    import sys
    from dirb39_probe2 import P0, GFL
    x = float(sys.argv[1])
    s = M2.build({b: x*P0[b] for b in GFL}, GFL); lam = M2.eig(s).real.max()
    for sg in [float(a) for a in sys.argv[2:]]:
        r = certify_shift(s, sg)
        print(f"x={x} (lambda_max {lam:.2f}) sigma={sg}: {r['certified']} {r.get('reason','')} evals {r.get('evals')} wT/2pi {r.get('wT',0)/2/np.pi:.0f} Hz passive {r.get('passive','')} [{r['time']:.0f}s]", flush=True)

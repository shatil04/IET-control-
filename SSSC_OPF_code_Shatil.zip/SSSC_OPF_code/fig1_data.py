import numpy as np, json, dirb39v2 as M2, bf_cert as BF
from dirb39_probe2 import P0, GFL
out = {}
fine = np.round(np.arange(110.0, 125.0001, 0.02), 3)
grid = np.geomspace(1e-3, 3e4, 4000); gs = grid[(grid >= 110) & (grid <= 125)]
for x in [0.8, 0.85]:
    s = M2.build({b: x*P0[b] for b in GFL}, GFL); d = []
    for f in fine:
        Y0, Ya, F = BF.parts(s, 2*np.pi*f); lam = np.linalg.eigvals(np.eye(len(Y0)) + np.linalg.solve(Y0, Ya)); d.append(float(BF.distneg(lam).min()))
    ds = []
    for f in gs:
        Y0, Ya, F = BF.parts(s, 2*np.pi*f); lam = np.linalg.eigvals(np.eye(len(Y0)) + np.linalg.solve(Y0, Ya)); ds.append(float(BF.distneg(lam).min()))
    out[str(x)] = dict(f=fine.tolist(), d=d, fs=[float(v) for v in gs], ds=ds)
    i = int(np.argmin(d)); print(x, "min dist", round(min(d), 5), "at", fine[i], "Hz | sampled min", round(min(ds), 4), "| samples in band", len(gs))
json.dump(out, open("fig1_data.json", "w"))

import os, sys, json, numpy as np, acopf as A, dirb39v2 as M2, bf_shift as BS
h = json.load(open(sys.argv[1])); x = np.array(h[-1]['x']); sg = float(sys.argv[2]); Pg, kw = A.bk(x); s = M2.build(Pg, A.GFL, **kw)
r = BS.certify_shift(s, sg); lam = M2.eig(s).real.max()
print(sys.argv[1], "load", os.environ.get("LOAD_SCALE"), "lambda_max", round(lam, 3), f"sigma {sg}:", r["certified"], r.get("reason", ""), f"evals {r.get('evals')} [{r['time']:.0f}s]", flush=True)
